/* ============================================================
   КиноФикация — Telegram Mini App
   «Тиндер для фильмов»: свайпаешь карточки, мэтчи — в общий список
   ============================================================ */

/* ---------- Telegram ---------- */
const tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
const IS_TG = !!(tg && tg.initData);
const API = '/api';

if (tg) {
  try {
    tg.ready();
    tg.expand();
    if (tg.setHeaderColor) tg.setHeaderColor('#0b0e17');
    if (tg.setBackgroundColor) tg.setBackgroundColor('#0b0e17');
    if (tg.disableVerticalSwipes) tg.disableVerticalSwipes();
    if (tg.enableClosingConfirmation) tg.enableClosingConfirmation();
  } catch (e) { /* не критично */ }
}
const tgUser = (IS_TG && tg.initDataUnsafe && tg.initDataUnsafe.user) || null;
const START_PARAM = IS_TG ? (tg.initDataUnsafe.start_param || '') : '';

/* ---------- утилиты ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cssEsc = (typeof CSS !== 'undefined' && CSS.escape)
  ? (x) => CSS.escape(x)
  : (x) => String(x).replace(/[^a-zA-Z0-9_-]/g, (c) => '\\' + c);
const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return Math.abs(h); };

function mulberry(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------- диалог подтверждения (window.confirm в Telegram WebView работает плохо) ---------- */
let confirmResolve = null;
function confirmDialog(text, okText, cancelText) {
  return new Promise((resolve) => {
    $('#confirmText').textContent = text;
    $('#confirmYes').textContent = okText || 'Да';
    $('#confirmNo').textContent = cancelText || 'Отмена';
    $('#confirmBox').classList.remove('hidden');
    confirmResolve = resolve;
  });
}
function closeConfirm(val) {
  $('#confirmBox').classList.add('hidden');
  if (confirmResolve) { const r = confirmResolve; confirmResolve = null; r(val); }
}

/* ---------- вибрация ---------- */
function haptic(kind, style) {
  if (!IS_TG || !tg.HapticFeedback) return;
  try {
    if (kind === 'impact') tg.HapticFeedback.impactOccurred(style || 'light');
    else if (kind === 'notify') tg.HapticFeedback.notificationOccurred(style || 'success');
    else if (kind === 'select') tg.HapticFeedback.selectionChanged();
  } catch (e) {}
}

/* ---------- тосты ---------- */
let toastT;
function toast(msg, type) {
  const el = $('#toast');
  el.textContent = msg;
  el.className = type || '';
  clearTimeout(toastT);
  toastT = setTimeout(() => el.classList.add('hidden'), 2600);
}

/* ============================================================
   СОСТОЯНИЕ
   ============================================================ */
const S = {
  catalog: [],
  byId: new Map(),
  me: null,
  partner: null,
  votes: {},          // { movieId: 1 | -1 }
  matches: [],        // [{id,title,year,poster,rating,src,ts,watched}]
  queue: [],          // карточки в колоде
  shown: 0,
  total: 0,
  filter: { type: 'all', genre: null, q: '' },
  history: [],        // для «отменить»
  demo: !IS_TG,
  apiError: null,
  genres: [],
  version: '',
  busy: false,
};

/* ============================================================
   API (Netlify Function) / демо-режим
   ============================================================ */
const LS = 'kinofik_demo_v1';
function demoLoad() {
  try { return JSON.parse(localStorage.getItem(LS) || '{}'); } catch { return {}; }
}
function demoSave() {
  try {
    localStorage.setItem(LS, JSON.stringify({ votes: S.votes, matches: S.matches, code: 'DEMO1' }));
  } catch (e) {}
}
// В демо-режиме «партнёр» лайкает детерминированно ~половину карточек
const demoPartnerLikes = (id) => hash('partner:' + id) % 100 < 55;

async function api(action, payload) {
  if (S.demo) return demoApi(action, payload);
  const body = JSON.stringify(Object.assign({ a: action, initData: tg.initData }, payload || {}));
  const r = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body,
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.ok === false) throw new Error(j.error || ('HTTP ' + r.status));
  return j;
}

function demoApi(action, p) {
  const d = demoLoad();
  if (action === 'hello') {
    S.votes = d.votes || {}; S.matches = d.matches || [];
    return Promise.resolve({
      me: { id: 1, first_name: 'Вы', code: d.code || 'DEMO1' },
      partner: { id: 2, first_name: 'Партнёр (демо)', code: 'DEMO2' },
      votes: S.votes, matches: S.matches, users: 2,
    });
  }
  if (action === 'vote') {
    S.votes[p.id] = p.v;
    let match = null;
    if (p.v === 1 && demoPartnerLikes(p.id) && !S.matches.some((m) => m.id === p.id)) {
      const it = S.byId.get(p.id);
      match = { id: it.id, title: it.title, year: it.year, poster: it.poster, rating: it.rating, src: it.src, type: it.type, ts: Date.now() };
      S.matches.unshift(match);
    }
    demoSave();
    return Promise.resolve({ match, votes: S.votes });
  }
  if (action === 'unvote') {
    delete S.votes[p.id];
    S.matches = S.matches.filter((m) => m.id !== p.id);
    demoSave();
    return Promise.resolve({ votes: S.votes, matches: S.matches });
  }
  if (action === 'unmatch') {
    S.matches = S.matches.filter((m) => m.id !== p.id);
    demoSave(); return Promise.resolve({ matches: S.matches });
  }
  if (action === 'watched') {
    const m = S.matches.find((x) => x.id === p.id); if (m) m.watched = !!p.v;
    demoSave(); return Promise.resolve({ matches: S.matches });
  }
  if (action === 'reset') { S.votes = {}; S.matches = []; demoSave(); return Promise.resolve({ votes: {}, matches: [] }); }
  if (action === 'pair') return Promise.resolve({ ok: false, error: 'В демо-режиме пара недоступна' });
  return Promise.resolve({});
}

/* ============================================================
   ЗАГРУЗКА
   ============================================================ */
async function boot() {
  try {
    const loadCatalog = () => window.__CATALOG__
      ? Promise.resolve(window.__CATALOG__)
      : fetch('data/movies.json').then((r) => { if (!r.ok) throw new Error('catalog ' + r.status); return r.json(); });
    const [cat] = await Promise.all([loadCatalog(), loadProfile()]);
    S.catalog = cat.items || [];
    S.version = cat.version || '';
    S.byId = new Map(S.catalog.map((i) => [i.id, i]));
    const gc = {};
    S.catalog.forEach((i) => (i.genres || []).forEach((g) => { gc[g] = (gc[g] || 0) + 1; }));
    S.genres = Object.keys(gc).sort((a, b) => gc[b] - gc[a]);

    buildGenreChips();
    buildQueue();
    paint();
    renderMatches();
    renderPair();
    renderProfile();
    $('#catalogInfo').textContent = `${S.catalog.length} фильмов и сериалов · база от ${S.version}`;
    $('#loader').classList.add('off');
    setTimeout(() => { const l = $('#loader'); if (l) l.style.display = 'none'; }, 400);

    if (S.demo) { $('#demoBanner').classList.remove('hidden'); document.body.classList.add('demo'); }
    if (!localStorage.getItem('kinofik_seen') && !S.demo) showOnboard();
    if (S.demo && !localStorage.getItem('kinofik_seen_demo')) showOnboard();

    // авто-пара по ссылке из Telegram
    if (IS_TG && /^pair_/.test(START_PARAM)) {
      try { await api('pair', { code: START_PARAM.slice(5) }); await refreshProfile(); toast('Пара связана 💞', 'ok'); } catch (e) {}
    }
  } catch (e) {
    console.error(e);
    $('#loader').innerHTML = `<div style="text-align:center;padding:30px;max-width:320px">
      <div style="font-size:44px;margin-bottom:12px">😕</div>
      <b style="font-size:17px">Не удалось загрузить каталог</b>
      <p style="color:#98a2b8;font-size:13px;line-height:1.6;margin:10px 0 18px">${esc(e.message)}</p>
      <button class="btn btn-primary" onclick="location.reload()">Попробовать снова</button></div>`;
  }
}

async function loadProfile() {
  try {
    const r = await api('hello');
    S.me = r.me || null;
    S.partner = r.partner || null;
    S.votes = r.votes || {};
    S.matches = r.matches || [];
    S.userCount = r.users || 1;
  } catch (e) {
    console.warn('profile error', e);
    S.apiError = e.message;
    if (!S.demo) toast('Сервер не ответил: ' + e.message, 'bad');
  }
}
async function refreshProfile() { await loadProfile(); renderMatches(); renderPair(); renderProfile(); buildQueue(); paint(); }

/* ============================================================
   КОЛОДА
   ============================================================ */
function passesFilter(it) {
  const f = S.filter;
  if (f.type !== 'all' && it.type !== f.type) return false;
  if (f.genre && !(it.genres || []).includes(f.genre)) return false;
  if (f.q) {
    const q = f.q.toLowerCase();
    const hay = ((it.title || '') + ' ' + (it.alt || '') + ' ' + (it.year || '') + ' ' + (it.genres || []).join(' ')).toLowerCase();
    if (!hay.includes(q)) return false;
  }
  return true;
}

function buildQueue() {
  const inFilter = S.catalog.filter((i) => passesFilter(i));
  const list = inFilter.filter((i) => !S.votes[i.id]);
  const seed = hash('deck:' + (S.me ? S.me.id : 'demo') + ':' + S.version);
  const rnd = mulberry(seed);
  const arr = list.slice();
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  // поиск: точное совпадение с началом названия → просто вхождение → остальное
  if (S.filter.q) {
    const q = S.filter.q.toLowerCase();
    const rank = (i) => {
      const t = (i.title || '').toLowerCase();
      const alt = (i.alt || '').toLowerCase();
      if (t === q) return 0;
      if (t.startsWith(q)) return 1;
      if (t.includes(q) || alt.includes(q)) return 2;
      return 3;
    };
    arr.sort((x, y) => (rank(x) - rank(y)) || ((y.rating || 0) - (x.rating || 0)));
  }
  S.queue = arr;
  S.shown = inFilter.length - arr.length;
  S.total = inFilter.length;
  updateProgress();
}

function updateProgress() {
  const pct = S.total ? Math.round((S.shown / S.total) * 100) : 0;
  $('#progressFill').style.width = pct + '%';
}

function rateClass(r) { return r == null ? '' : r >= 7.5 ? 'great' : r >= 6.5 ? 'good' : r >= 5 ? 'mid' : 'low'; }
const SRC_LABEL = { kp: 'КиноПоиск', tmdb: 'TMDB' };

function cardHTML(it) {
  const isSeries = it.type === 'series';
  const dur = isSeries
    ? [it.seasons ? it.seasons + ' сез.' : null, it.episodes ? it.episodes + ' сер.' : null].filter(Boolean).join(' · ')
    : (it.minutes ? Math.floor(it.minutes / 60) + ' ч ' + (it.minutes % 60) + ' мин' : '');
  const meta = [it.year, isSeries ? 'сериал' : 'фильм', it.country, dur, it.age].filter(Boolean);
  const poster = it.poster
    ? `<img class="card-img" src="${esc(it.poster)}" alt="" loading="lazy" decoding="async"
         onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
       <div class="card-noposter" style="display:none;background:linear-gradient(150deg,#2a2140,#141a2c)"><span style="font-size:40px">🎬</span><span>${esc(it.title)}</span></div>`
    : `<div class="card-noposter" style="background:linear-gradient(150deg,#2a2140,#141a2c)"><span style="font-size:40px">🎬</span><span>${esc(it.title)}</span></div>`;

  return `
    ${poster}
    <div class="card-grad"></div>
    <div class="card-top">
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <span class="tag ${isSeries ? 'series' : 'movie'}">${isSeries ? 'Сериал' : 'Фильм'}</span>
        ${it.age ? `<span class="tag age">${esc(it.age)}</span>` : ''}
      </div>
      ${it.rating != null ? `<div class="rate-badge ${rateClass(it.rating)}"><b>${it.rating.toFixed(1)}</b><small>${SRC_LABEL[it.src] || 'рейтинг'}</small></div>` : ''}
    </div>
    <div class="card-body">
      <h2 class="card-title">${esc(it.title)}</h2>
      ${it.alt && it.alt !== it.title ? `<div class="card-alt">${esc(it.alt)}</div>` : ''}
      <div class="card-meta">${meta.map((m, i) => `${i ? '<span class="dot"></span>' : ''}${esc(m)}`).join('')}</div>
      <div class="card-genres">${(it.genres || []).slice(0, 4).map((g) => `<span class="g">${esc(g)}</span>`).join('')}</div>
      ${it.tagline ? `<p class="card-tagline">«${esc(it.tagline)}»</p>` : ''}
    </div>
    <div class="stamp yes">Нравится</div>
    <div class="stamp no">Мимо</div>`;
}

function paint() {
  const deck = $('#deck');
  const top = S.queue.slice(0, 3);
  const keep = new Set(top.map((i) => i.id));
  $$('.card', deck).forEach((el) => { if (!keep.has(el.dataset.id)) el.remove(); });

  top.forEach((it, idx) => {
    let el = deck.querySelector(`.card[data-id="${cssEsc(it.id)}"]`);
    if (!el) {
      el = document.createElement('div');
      el.className = 'card';
      el.dataset.id = it.id;
      el.innerHTML = cardHTML(it);
      deck.appendChild(el);
    }
    el.style.transform = '';
    el.style.opacity = '';
    el.classList.remove('behind1', 'behind2', 'drag', 'fly', 'gone', 'post');
    if (idx === 1) el.classList.add('behind1');
    if (idx === 2) el.classList.add('behind2');
    el.style.zIndex = String(10 - idx);
    const ys = el.querySelector('.stamp.yes'), ns = el.querySelector('.stamp.no');
    if (ys) ys.style.opacity = 0; if (ns) ns.style.opacity = 0;
  });

  const empty = top.length === 0;
  $('#emptyDeck').classList.toggle('hidden', !empty);
  $('#actions').style.visibility = empty ? 'hidden' : 'visible';
  if (empty) {
    const filtered = S.filter.type !== 'all' || S.filter.genre || S.filter.q;
    $('#emptyText').innerHTML = filtered
      ? 'В этой категории карточки закончились.<br>Смените фильтр или сбросьте его.'
      : 'Вы оценили всё, что было в каталоге!<br>Загляните во вкладку «Мэтчи» 🍿';
    $('#btnResetFilter').style.display = filtered ? '' : 'none';
    $('#btnStartOver').style.display = filtered ? 'none' : '';
  }
  preload(top);
}

function preload(list) {
  list.slice(1, 3).forEach((it) => { if (it.poster) { const i = new Image(); i.src = it.poster; } });
  const next = S.queue[3]; if (next && next.poster) { const i = new Image(); i.src = next.poster; }
}

/* ---------- свайпы ---------- */
let drag = null, animating = false, hapticsFired = false;

function topEl() { const d = S.queue[0]; return d ? $('#deck').querySelector(`.card[data-id="${cssEsc(d.id)}"]`) : null; }

function onDown(e) {
  if (animating || drag) return;
  const el = topEl(); if (!el) return;
  if (e.target.closest('button')) return;
  drag = { x0: e.clientX, y0: e.clientY, dx: 0, dy: 0, t0: performance.now(), el };
  hapticsFired = false;
  el.classList.add('drag');
  try { el.setPointerCapture(e.pointerId); } catch (err) {}
  e.preventDefault();
}
function onMove(e) {
  if (!drag) return;
  drag.dx = e.clientX - drag.x0;
  drag.dy = e.clientY - drag.y0;
  const rot = Math.max(-24, Math.min(24, drag.dx / 16));
  drag.el.style.transform = `translate(${drag.dx}px, ${drag.dy * 0.4}px) rotate(${rot}deg)`;
  const p = Math.min(Math.abs(drag.dx) / 105, 1);
  const ys = drag.el.querySelector('.stamp.yes'), ns = drag.el.querySelector('.stamp.no');
  if (ys) ys.style.opacity = drag.dx > 0 ? p : 0;
  if (ns) ns.style.opacity = drag.dx < 0 ? p : 0;
  if (!hapticsFired && Math.abs(drag.dx) > 105) { hapticsFired = true; haptic('select'); }
}
function onUp() {
  if (!drag) return;
  const { dx, el, t0 } = drag; drag = null;
  el.classList.remove('drag');
  const dt = Math.max(1, performance.now() - t0);
  const vel = Math.abs(dx) / dt;
  if (Math.abs(dx) > 96 || (vel > 0.85 && Math.abs(dx) > 30)) vote(dx > 0 ? 1 : -1);
  else {
    el.classList.add('post');
    el.style.transform = '';
    const ys = el.querySelector('.stamp.yes'), ns = el.querySelector('.stamp.no');
    if (ys) ys.style.opacity = 0; if (ns) ns.style.opacity = 0;
    setTimeout(() => el && el.classList.remove('post'), 320);
  }
}

function vote(dir, silent) {
  if (animating) return;
  const it = S.queue[0]; if (!it) return;
  const el = topEl(); if (!el) { advance(it, dir); return; }
  animating = true;
  const W = window.innerWidth;
  const cur = el.style.transform.match(/translate\(([-\d.]+)px,\s*([-\d.]+)px\)/);
  const dy = cur ? parseFloat(cur[2]) : 0;
  el.classList.add('fly');
  el.style.transform = `translate(${dir * W * 1.5}px, ${dy}px) rotate(${dir * 26}deg)`;
  el.classList.add('gone');
  haptic('impact', dir > 0 ? 'medium' : 'light');
  setTimeout(() => { animating = false; advance(it, dir, el); }, 260);
}

function advance(it, dir, el) {
  if (el) el.remove();
  S.history.push({ item: it, dir });
  if (S.history.length > 30) S.history.shift();
  S.queue.shift();
  S.shown++; updateProgress();
  paint();
  saveVote(it, dir);
}

// Голос за конкретный фильм — даже если его сейчас нет наверху колоды
async function voteItem(it, dir) {
  if (!it) return;
  if (S.queue[0] && S.queue[0].id === it.id) { vote(dir); return; }
  const prev = S.votes[it.id];
  S.votes[it.id] = dir;
  haptic('impact', dir > 0 ? 'medium' : 'light');
  try {
    const r = await api('vote', { id: it.id, v: dir });
    if (r && r.match) showMatch(Object.assign({}, it, r.match));
    else toast(dir > 0 ? '❤️ «' + it.title + '» — хочу посмотреть' : '✖️ «' + it.title + '» — мимо', dir > 0 ? 'ok' : '');
  } catch (e) {
    if (prev === undefined) delete S.votes[it.id]; else S.votes[it.id] = prev;
    toast('Не удалось сохранить: ' + e.message, 'bad');
  }
  buildQueue(); paint();
}

async function saveVote(it, dir) {
  try {
    const r = await api('vote', { id: it.id, v: dir, t: it.title, y: it.year, p: it.poster, rt: it.rating, s: it.src, tp: it.type });
    S.votes[it.id] = dir;
    if (r && r.match) {
      if (r.match.poster == null) r.match = Object.assign({}, r.match, {
        title: it.title, year: it.year, poster: it.poster, rating: it.rating, src: it.src, type: it.type,
      });
      showMatch(r.match);
    }
  } catch (e) {
    console.warn('vote error', e);
    S.votes[it.id] = dir; // локально всё равно запоминаем
    if (!S.demo) toast('Не удалось сохранить: ' + e.message, 'bad');
  }
}

/* ---------- отменить ---------- */
async function undo() {
  const last = S.history.pop();
  if (!last) { toast('Отменять нечего'); return; }
  const { item, dir } = last;
  delete S.votes[item.id];
  S.matches = S.matches.filter((m) => m.id !== item.id);
  S.queue.unshift(item);
  S.shown = Math.max(0, S.shown - 1);
  updateProgress(); paint(); renderMatches();
  haptic('impact', 'light');
  try { await api('unvote', { id: item.id }); } catch (e) { console.warn(e); }
  toast('«' + item.title + '» вернулась в колоду');
}

/* ============================================================
   МЭТЧ
   ============================================================ */
function showMatch(m) {
  const it = S.byId.get(m.id) || {};
  const data = Object.assign({}, it, m);
  if (!S.matches.some((x) => x.id === data.id)) S.matches.unshift({
    id: data.id, title: data.title, year: data.year, poster: data.poster,
    rating: data.rating, src: data.src, type: data.type, ts: data.ts || Date.now(),
  });
  renderMatches();
  $('#matchTitle').textContent = data.title || '';
  $('#matchMeta').textContent = [data.year, data.type === 'series' ? 'сериал' : 'фильм',
    (data.genres || []).slice(0, 2).join(', ')].filter(Boolean).join(' · ');
  $('#matchRate').textContent = data.rating ? '★ ' + Number(data.rating).toFixed(1) : '';
  $('#matchSub').textContent = S.demo
    ? 'Демо: мэтч сымитирован, чтобы вы увидели, как это выглядит'
    : (S.partner
      ? `Вы и ${S.partner.first_name || 'партнёр'} хотите это посмотреть`
      : 'Вы оба хотите это посмотреть');
  const img = $('#matchPoster');
  if (data.poster) { img.src = data.poster; img.style.display = ''; } else { img.style.display = 'none'; }
  $('#matchOverlay').classList.remove('hidden');
  confetti();
  haptic('notify', 'success');
  setTimeout(() => haptic('notify', 'success'), 260);
}

let confRAF;
function confetti() {
  const cv = $('#confetti'); const ctx = cv && cv.getContext ? cv.getContext('2d') : null;
  if (!ctx) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  cv.width = cv.offsetWidth * dpr; cv.height = cv.offsetHeight * dpr; ctx.scale(dpr, dpr);
  const W = cv.offsetWidth, H = cv.offsetHeight;
  const colors = ['#ff5c8a', '#ffc857', '#7c5cff', '#3ddc84', '#8fd3ff', '#ffffff'];
  const P = Array.from({ length: 130 }, () => ({
    x: W / 2 + (Math.random() - 0.5) * 60, y: H / 2 - 40,
    vx: (Math.random() - 0.5) * 11, vy: -Math.random() * 13 - 3,
    w: 4 + Math.random() * 7, h: 6 + Math.random() * 9,
    c: colors[(Math.random() * colors.length) | 0], a: Math.random() * Math.PI, va: (Math.random() - 0.5) * 0.3, life: 1,
  }));
  const t0 = performance.now();
  cancelAnimationFrame(confRAF);
  (function frame() {
    const t = performance.now() - t0;
    ctx.clearRect(0, 0, W, H);
    P.forEach((p) => {
      p.vy += 0.34; p.vx *= 0.992; p.x += p.vx; p.y += p.vy; p.a += p.va;
      p.life = Math.max(0, 1 - t / 2800);
      ctx.save(); ctx.globalAlpha = p.life; ctx.translate(p.x, p.y); ctx.rotate(p.a);
      ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
    });
    if (t < 2900) confRAF = requestAnimationFrame(frame); else ctx.clearRect(0, 0, W, H);
  })();
}

/* ============================================================
   СПИСОК МЭТЧЕЙ
   ============================================================ */
function renderMatches() {
  const list = $('#matchList');
  const arr = (S.matches || []).slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
  $('#matchCount').textContent = arr.length;
  const badge = $('#matchBadge');
  badge.textContent = arr.length; badge.classList.toggle('hidden', !arr.length);
  $('#emptyMatches').classList.toggle('hidden', arr.length > 0);
  list.innerHTML = arr.map((m) => {
    const it = S.byId.get(m.id) || m;
    const isSeries = (it.type || m.type) === 'series';
    return `<div class="mrow" data-id="${esc(m.id)}">
      ${it.poster ? `<img src="${esc(it.poster)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<div style="width:56px;height:84px;border-radius:10px;background:#0f1420;flex:0 0 auto"></div>`}
      <div class="mtext">
        <h3>${esc(it.title || m.title || '')}</h3>
        <div class="mmeta">${[it.year || m.year, isSeries ? 'сериал' : 'фильм', (it.genres || []).slice(0, 2).join(', ')].filter(Boolean).map(esc).join(' · ')}</div>
        ${it.rating ? `<div class="mrate">★ ${Number(it.rating).toFixed(1)} <span style="color:var(--dim);font-weight:500">${SRC_LABEL[it.src] || ''}</span></div>` : ''}
      </div>
      <button class="mx" data-act="del" title="Убрать">✕</button>
      ${m.watched ? `<div class="mwatched">✓ ПОСМОТРЕЛИ</div>` : ''}
    </div>`;
  }).join('');
}

/* ============================================================
   ЭКРАН «ПАРА»
   ============================================================ */
function avatar(u) {
  if (!u) return '';
  const letter = (u.first_name || '?').trim().charAt(0).toUpperCase();
  return u.photo_url ? `<div class="av"><img src="${esc(u.photo_url)}" alt=""></div>` : `<div class="av">${esc(letter)}</div>`;
}

function renderPair() {
  const box = $('#pairStatus');
  if (S.demo) {
    box.innerHTML = `<div class="status-wait"><span class="ico">🧪</span>
      <p><b>Демо-режим.</b> Страница открыта вне Telegram, поэтому мэтчи здесь имитируются —
      так вы можете посмотреть, как всё выглядит и работает. Внутри бота всё будет по-настоящему:
      реальные голоса, реальные уведомления обоим.</p></div>`;
  } else if (S.partner) {
    box.innerHTML = `<div class="status-ok">${avatar(S.partner)}
      <div><b>${esc(S.partner.first_name || 'Партнёр')}</b>
      <span>Вы связаны 💞 · мэтчи приходят обоим</span></div></div>`;
  } else if (S.apiError) {
    box.innerHTML = `<div class="status-wait"><span class="ico">⚠️</span>
      <p><b>Сервер не отвечает.</b><br>${esc(S.apiError)}<br><br>
      Если вы только что развернули сайт — откройте в браузере адрес
      <b>ваш-сайт.netlify.app/setup</b> и нажмите кнопку настройки.
      Затем перезапустите приложение.</p></div>`;
  } else {
    box.innerHTML = `<div class="status-wait"><span class="ico">⏳</span>
      <p><b>Партнёр ещё не подключён.</b><br>Пусть он откроет бота, нажмёт «Старт» и введёт ваш код — или отправьте ему ссылку ниже.</p></div>`;
  }
  $('#myCode').textContent = S.me && S.me.code ? S.me.code : '····';
}

function renderProfile() {
  const u = S.me || tgUser;
  $('#profileBox').innerHTML = u
    ? `${avatar(u)}<div><b>${esc(u.first_name || 'Вы')}</b><small>${u.username ? '@' + esc(u.username) : 'Telegram ID ' + esc(u.id || '')}</small></div>`
    : `<div><b>Гость</b><small>Откройте приложение через бота</small></div>`;
}

async function doPair() {
  const code = $('#partnerCode').value.trim().toUpperCase();
  const msg = $('#pairMsg');
  if (!code) { msg.textContent = 'Введите код'; return; }
  msg.textContent = 'Проверяем…';
  try {
    const r = await api('pair', { code });
    if (r && r.ok === false) throw new Error(r.error || 'не вышло');
    msg.textContent = '';
    await refreshProfile();
    toast('Пара связана 💞', 'ok');
    haptic('notify', 'success');
  } catch (e) {
    msg.textContent = '⚠ ' + e.message;
  }
}

function shareLink() {
  if (!S.me || !S.me.code) { toast('Сначала откройте приложение через бота'); return; }
  const bot = (IS_TG && tg.initDataUnsafe && tg.initDataUnsafe.bot) ? tg.initDataUnsafe.bot.username : '';
  const link = `https://t.me/${bot || 'kino_fik_bot'}?start=pair_${S.me.code}`;
  if (IS_TG && tg.openTelegramLink) { tg.openTelegramLink(link); return; }
  if (navigator.share) { navigator.share({ title: 'КиноФикация', text: 'Подключись ко мне — будем вместе выбирать кино!', url: link }).catch(() => {}); return; }
  navigator.clipboard && navigator.clipboard.writeText(link).then(() => toast('Ссылка скопирована'), () => toast(link));
}

/* ============================================================
   МОДАЛКА С ПОДРОБНОСТЯМИ
   ============================================================ */
let modalItem = null;
function openInfo(item) {
  modalItem = item || S.queue[0];
  if (!modalItem) return;
  const it = modalItem;
  const isSeries = it.type === 'series';
  const dur = isSeries
    ? [it.seasons ? it.seasons + ' сезона(ов)' : null, it.episodes ? it.episodes + ' серий' : null].filter(Boolean).join(', ')
    : (it.minutes ? Math.floor(it.minutes / 60) + ' ч ' + (it.minutes % 60) + ' мин' : null);
  const voted = S.votes[it.id];

  $('#modalBody').innerHTML = `
    <div class="m-hero">${it.backdrop ? `<img class="bd" src="${esc(it.backdrop)}" alt="" onerror="this.style.display='none'">` : ''}<div class="fade"></div></div>
    <div class="m-head">
      ${it.poster ? `<img src="${esc(it.poster)}" alt="" onerror="this.style.display='none'">` : ''}
      <div class="m-titles">
        <h2>${esc(it.title)}</h2>
        ${it.alt ? `<div class="alt">${esc(it.alt)}</div>` : ''}
        <div class="meta">${[it.year, isSeries ? 'сериал' : 'фильм', it.country, it.age].filter(Boolean).map(esc).join(' · ')}</div>
        ${dur ? `<div class="meta" style="margin-top:3px">⏱ ${esc(dur)}</div>` : ''}
      </div>
    </div>
    <div class="m-stats">
      ${it.src === 'kp' && it.rating != null ? `<div class="stat"><b class="kp">${it.rating.toFixed(1)}</b><small>КиноПоиск</small></div>` : ''}
      ${it.src === 'tmdb' && it.rating != null ? `<div class="stat"><b class="tmdb">${it.rating.toFixed(1)}</b><small>TMDB</small></div>` : ''}
      ${it.imdb ? `<div class="stat"><b class="imdb">${it.imdb.toFixed(1)}</b><small>IMDb</small></div>` : ''}
      ${it.votes ? `<div class="stat"><b style="color:#c9d2e6">${fmtVotes(it.votes)}</b><small>голосов</small></div>` : ''}
    </div>
    <div class="m-sec">
      ${it.tagline ? `<p class="m-tagline">«${esc(it.tagline)}»</p>` : ''}
      <h4>Описание</h4>
      <p class="m-desc">${esc(it.description || 'Описания пока нет.')}</p>
    </div>
    ${(it.genres || []).length ? `<div class="m-sec"><h4>Жанры</h4><div class="m-genres">${it.genres.map((g) => `<span class="g">${esc(g)}</span>`).join('')}</div></div>` : ''}
    <div class="m-actions">
      <button class="btn btn-no" id="mNo">${voted === -1 ? '✖️ Уже «мимо»' : '👎 Мимо'}</button>
      <button class="btn btn-like" id="mYes">${voted === 1 ? '❤️ Уже хочу' : '👍 Хочу смотреть'}</button>
    </div>`;
  $('#modal').classList.remove('hidden');
  setBack(closeModal);
  $('#mYes').onclick = () => { closeModal(); voteItem(it, 1); };
  $('#mNo').onclick = () => { closeModal(); voteItem(it, -1); };
}
function fmtVotes(n) {
  n = +n || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(1).replace('.0', '') + ' млн';
  if (n >= 1e3) return Math.round(n / 1e3) + ' тыс';
  return String(n);
}
function closeModal() {
  $('#modal').classList.add('hidden');
  modalItem = null;
  setBack($('.screen.active') && $('.screen.active').id !== 'screen-deck' ? () => switchScreen('deck') : null);
}

/* ============================================================
   ОНБОРДИНГ
   ============================================================ */
function showOnboard() {
  $('#onboard').classList.remove('hidden');
}

/* ============================================================
   ФИЛЬТРЫ / ЖАНРЫ
   ============================================================ */
function buildGenreChips() {
  const box = $('#genreChips');
  box.innerHTML = S.genres.map((g) => `<button class="chip" data-genre="${esc(g)}">${esc(g)}</button>`).join('');
}

let backHandler = null;
function setBack(fn) {
  if (!IS_TG || !tg.BackButton) return;
  try {
    if (backHandler) tg.BackButton.offClick(backHandler);
    if (fn) { backHandler = fn; tg.BackButton.onClick(backHandler); tg.BackButton.show(); }
    else { backHandler = null; tg.BackButton.hide(); }
  } catch (e) {}
}

function switchScreen(name) {
  $$('.screen').forEach((s) => s.classList.toggle('active', s.id === 'screen-' + name));
  $$('.tab').forEach((t) => t.classList.toggle('on', t.dataset.screen === name));
  if (name !== 'deck') { $('#searchWrap').classList.add('hidden'); document.body.classList.remove('search-open'); }
  setBack(name === 'deck' ? null : () => switchScreen('deck'));
  if (name === 'matches') renderMatches();
  if (name === 'pair') { renderPair(); renderProfile(); }
}

/* ============================================================
   СОБЫТИЯ
   ============================================================ */
function bind() {
  const deck = $('#deck');
  deck.addEventListener('pointerdown', onDown);
  deck.addEventListener('pointermove', onMove);
  deck.addEventListener('pointerup', onUp);
  deck.addEventListener('pointercancel', onUp);

  $('#btnYes').onclick = () => { pulse('#btnYes'); vote(1); };
  $('#btnNo').onclick = () => { pulse('#btnNo'); vote(-1); };
  $('#btnInfo').onclick = () => openInfo();
  $('#btnUndo').onclick = undo;
  $('#matchOk').onclick = () => { $('#matchOverlay').classList.add('hidden'); cancelAnimationFrame(confRAF); haptic('impact', 'light'); };
  $('#modalClose').onclick = closeModal;
  $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') closeModal(); });
  $('#obStart').onclick = () => {
    $('#onboard').classList.add('hidden');
    localStorage.setItem('kinofik_seen', '1'); localStorage.setItem('kinofik_seen_demo', '1');
    haptic('impact', 'medium');
  };
  $('#btnGoDeck').onclick = () => switchScreen('deck');
  $('#btnResetFilter').onclick = () => {
    S.filter = { type: 'all', genre: null, q: '' };
    $('#searchInput').value = '';
    $('#searchWrap').classList.add('hidden');
    document.body.classList.remove('search-open');
    $$('#typeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.type === 'all'));
    $$('.chip').forEach((c) => c.classList.remove('on'));
    buildQueue(); paint();
    toast('Фильтры сброшены');
  };
  $('#btnStartOver').onclick = async () => {
    const yes = await confirmDialog('Оценить все фильмы заново? Текущие оценки и мэтчи будут удалены.', 'Сбросить');
    if (!yes) return;
    try {
      await api('reset');
      S.votes = {}; S.matches = []; S.history = [];
      buildQueue(); paint(); renderMatches();
      toast('Колода обновлена 🔄', 'ok');
    } catch (e) { toast('Ошибка: ' + e.message, 'bad'); }
  };

  $$('.tab').forEach((t) => t.onclick = () => { switchScreen(t.dataset.screen); haptic('select'); });
  $$('#typeSeg button').forEach((b) => b.onclick = () => {
    $$('#typeSeg button').forEach((x) => x.classList.remove('on'));
    b.classList.add('on');
    S.filter.type = b.dataset.type;
    haptic('select'); buildQueue(); paint();
  });
  $('#genreChips').addEventListener('click', (e) => {
    const b = e.target.closest('.chip'); if (!b) return;
    const g = b.dataset.genre;
    S.filter.genre = S.filter.genre === g ? null : g;
    $$('.chip').forEach((c) => c.classList.toggle('on', c.dataset.genre === S.filter.genre));
    haptic('select'); buildQueue(); paint();
  });

  $('#confirmYes').onclick = () => { haptic('impact', 'medium'); closeConfirm(true); };
  $('#confirmNo').onclick = () => closeConfirm(false);
  $('#confirmBox').addEventListener('click', (e) => { if (e.target.id === 'confirmBox') closeConfirm(false); });

  $('#btnSearch').onclick = () => {
    const w = $('#searchWrap');
    w.classList.toggle('hidden');
    document.body.classList.toggle('search-open', !w.classList.contains('hidden'));
    if (!w.classList.contains('hidden')) setTimeout(() => $('#searchInput').focus(), 120);
    else { $('#searchInput').value = ''; S.filter.q = ''; buildQueue(); paint(); }
  };
  let sT;
  $('#searchInput').addEventListener('input', (e) => {
    clearTimeout(sT);
    const v = e.target.value.trim();
    sT = setTimeout(() => { S.filter.q = v; buildQueue(); paint(); }, 180);
  });

  $('#btnPair').onclick = doPair;
  $('#btnShare').onclick = shareLink;
  $('#partnerCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') doPair(); });
  $('#btnReset').onclick = async () => {
    const yes = await confirmDialog('Удалить все ваши оценки и мэтчи? Отменить это будет нельзя.', 'Удалить');
    if (!yes) return;
    try {
      await api('reset');
      S.votes = {}; S.matches = []; S.history = [];
      buildQueue(); paint(); renderMatches();
      toast('Данные сброшены', 'ok');
    } catch (e) { toast('Ошибка: ' + e.message, 'bad'); }
  };

  // клик по строке мэтча — подробности; по ✕ — убрать
  $('#matchList').addEventListener('click', async (e) => {
    const row = e.target.closest('.mrow'); if (!row) return;
    const id = row.dataset.id;
    if (e.target.closest('[data-act="del"]')) {
      row.style.transition = '.25s'; row.style.opacity = '0'; row.style.transform = 'translateX(40px)';
      setTimeout(() => row.remove(), 240);
      S.matches = S.matches.filter((m) => m.id !== id);
      try { await api('unmatch', { id }); } catch (err) {}
      renderMatches();
      toast('Убрано из мэтчей');
      return;
    }
    const it = S.byId.get(id);
    if (it) openInfo(it);
  });

  // долгое нажатие по карточке — подробности
  let lpT;
  deck.addEventListener('pointerdown', (e) => {
    clearTimeout(lpT);
    lpT = setTimeout(() => { if (drag && Math.abs(drag.dx) < 8) { drag = null; const el = topEl(); if (el) { el.classList.remove('drag'); el.style.transform = ''; } openInfo(); } }, 480);
  });
  ['pointerup', 'pointercancel', 'pointermove'].forEach((ev) => deck.addEventListener(ev, () => {
    if (ev === 'pointermove' && drag && (Math.abs(drag.dx) > 8)) clearTimeout(lpT);
    if (ev !== 'pointermove') clearTimeout(lpT);
  }));

  // клавиатура (для теста в браузере)
  document.addEventListener('keydown', (e) => {
    if (!$('#screen-deck').classList.contains('active')) return;
    if (e.key === 'ArrowRight') { pulse('#btnYes'); vote(1); }
    else if (e.key === 'ArrowLeft') { pulse('#btnNo'); vote(-1); }
    else if (e.key === 'i' || e.key === 'I' || e.key === 'ш') openInfo();
    else if ((e.key === 'z' || e.key === 'Z') && (e.ctrlKey || e.metaKey)) { e.preventDefault(); undo(); }
  });

  if (tg) {
    tg.onEvent && tg.onEvent('viewportChanged', () => { try { tg.expand(); } catch (e) {} });
  }
}

function pulse(sel) {
  const b = $(sel); if (!b) return;
  b.classList.remove('pulse'); void b.offsetWidth; b.classList.add('pulse');
}

/* ============================================================
   ФОНОВАЯ АНИМАЦИЯ
   ============================================================ */
function bgfx() {
  const cv = $('#bgfx'); if (!cv || !cv.getContext) return;
  const ctx = cv.getContext('2d');
  if (!ctx || !ctx.createRadialGradient) return;
  let W, H, blobs;
  function size() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    W = cv.offsetWidth; H = cv.offsetHeight;
    cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  function init() {
    size();
    blobs = [
      { x: .22, y: .18, r: .46, c: '124,92,255', s: .00006, p: 0 },
      { x: .82, y: .32, r: .40, c: '255,92,138', s: .00008, p: 2 },
      { x: .5, y: .88, r: .52, c: '40,120,255', s: .00005, p: 4 },
    ];
  }
  let last = 0;
  function frame(t) {
    requestAnimationFrame(frame);
    if (t - last < 90) return; // ~11 кадров/с — движение очень плавное и медленное
    last = t;
    ctx.clearRect(0, 0, W, H);
    blobs.forEach((b) => {
      const x = (b.x + Math.sin(t * b.s + b.p) * .07) * W;
      const y = (b.y + Math.cos(t * b.s * 1.3 + b.p) * .06) * H;
      const g = ctx.createRadialGradient(x, y, 0, x, y, b.r * Math.max(W, H));
      g.addColorStop(0, `rgba(${b.c},.20)`);
      g.addColorStop(1, `rgba(${b.c},0)`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    });
  }
  init();
  window.addEventListener('resize', size);
  requestAnimationFrame(frame);
}

/* ============================================================
   СТАРТ
   ============================================================ */
bind();
bgfx();
boot();

// Небольшая отладочная ручка (ни на что не влияет).
// В консоли браузера можно написать KinoFik.state и посмотреть внутренности.
try { window.KinoFik = { state: S, version: 1 }; } catch (e) {}
