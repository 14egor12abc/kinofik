// Сбор каталога: TMDB (постеры, описания, жанры) + Wikidata → ID КиноПоиска → настоящие рейтинги КП
import { TITLES } from './titles.mjs';
import { writeFileSync, existsSync, readFileSync } from 'node:fs';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const H = { 'User-Agent': UA, 'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8' };
const WIKIDATA_UA = 'KinoFikBot/1.0 (private Telegram mini-app; mail@example.com) node';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function get(url, headers = H, tries = 3) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(url, { headers });
      if (r.status === 429) { await sleep(1500 * (i + 1)); continue; }
      if (!r.ok && i < tries - 1) { await sleep(700 * (i + 1)); continue; }
      return { status: r.status, text: await r.text() };
    } catch (e) {
      if (i === tries - 1) return { status: 0, text: '', err: e.message };
      await sleep(700 * (i + 1));
    }
  }
  return { status: 0, text: '' };
}

const decode = (s) => String(s)
  .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'")
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
  .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
  .replace(/&nbsp;/g, ' ').trim();

const isoToMinutes = (iso) => {
  if (!iso) return null;
  const m = String(iso).match(/PT(?:(\d+)H)?(?:(\d+)M)?/i);
  if (!m) return null;
  const v = (+m[1] || 0) * 60 + (+m[2] || 0);
  return v || null;
};

function parseLD(html) {
  const m = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
  if (!m) return null;
  const raw = m[1].replace(/\/\* <!\[CDATA\[ \*\//g, '').replace(/\/\* \]\]> \*\//g, '').trim();
  try { return JSON.parse(raw); } catch { return null; }
}

function firstOf(html, re) {
  const m = html.match(re);
  return m ? decode(m[1].replace(/<[^>]+>/g, '')).trim() : null;
}

// Похоже ли найденное название на то, что мы искали
const norm = (x) => String(x || '').toLowerCase().replace(/ё/g, 'е').replace(/[^a-zа-я0-9 ]/gi, ' ').replace(/\s+/g, ' ').trim();
function sim(a, b) {
  a = norm(a); b = norm(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  const bg = (s) => { const m = new Set(); for (let i = 0; i < s.length - 1; i++) m.add(s.slice(i, i + 2)); return m; };
  const A = bg(a), B = bg(b);
  let inter = 0; for (const x of A) if (B.has(x)) inter++;
  return (2 * inter) / (A.size + B.size);
}

// Ручные исправления (когда автопоиск может ошибиться)
const FORCE = { 'Реальные пацаны': { type: 'tv', id: 46005 } };
const FORCE_KP = { 'Реальные пацаны': 568082 };

async function fetchDetails(type, id) {
  const { text } = await get(`https://www.themoviedb.org/${type}/${id}?language=ru-RU`);
  const ld = parseLD(text);
  const out = { tmdbId: +id };
  if (ld) {
    out.title = ld.name || null;
    out.description = (ld.description || '').trim() || null;
    out.genres = Array.isArray(ld.genre) ? ld.genre : (ld.genre ? [ld.genre] : []);
    out.ratingTmdb = ld.aggregateRating?.ratingValue ?? null;
    out.votesTmdb = ld.aggregateRating?.ratingCount ?? null;
    out.countries = (ld.countryOfOrigin || []).map((c) => c.name);
    out.minutes = isoToMinutes(ld.duration);
    out.episodes = ld.numberOfEpisodes ?? null;
    out.seasons = ld.numberOfSeasons ?? null;
    const d = (ld.releasedEvent && ld.releasedEvent[0] && ld.releasedEvent[0].startDate) || ld.startDate || ld.datePublished || null;
    out.date = typeof d === 'string' ? d.slice(0, 10) : null;
    out.poster = ld.image || null;
  }
  out.originalTitle = firstOf(text, /<strong>Исходное название<\/strong>\s*([^<]+)</);
  out.tagline = firstOf(text, /<h3 class="tagline"[^>]*>([^<]+)</);
  if (out.tagline) out.tagline = out.tagline.replace(/^«|»$/g, '');
  out.ageRating = firstOf(text, /<span class="certification">\s*([^<]+?)\s*</);
  if (!out.minutes) {
    const m = text.match(/(\d+)h\s*(\d+)m/);
    out.minutes = m ? (+m[1]) * 60 + (+m[2]) : null;
  }
  const posterHash = (out.poster || '').match(/\/([A-Za-z0-9]+)\.(?:jpg|png)$/);
  const backdrops = [...new Set([...text.matchAll(/https:\/\/(?:media|image)\.themoviedb\.org\/t\/p\/(?:original|w1280|w780|w533_and_h300_face)\/([A-Za-z0-9]+)\.(?:jpg|png)/g)].map((m) => m[1]))]
    .filter((h) => !posterHash || h !== posterHash[1]);
  out.backdrop = backdrops.length ? `https://image.tmdb.org/t/p/w1280/${backdrops[0]}.jpg` : null;
  out.poster = posterHash ? `https://image.tmdb.org/t/p/w500/${posterHash[1]}.jpg` : null;
  return out;
}

function parseCards(text) {
  const out = [];
  for (const c of text.split('comp:media-card').slice(1)) {
    const h = c.match(/href="\/(movie|tv)\/(\d+)/);
    if (!h) continue;
    const ti = c.match(/<h2[^>]*>\s*(?:<span>)?([^<]+)/);
    const rd = c.match(/release_date[^>]*>([^<]*)</);
    const ym = rd ? rd[1].match(/\b(?:19|20)\d{2}\b/) : null;
    out.push({
      type: h[1], id: h[2],
      title: ti ? decode(ti[1]) : '',
      year: ym ? +ym[0] : null,
      hasImage: /themoviedb\.org\/t\/p\/w94_and_h141/.test(c),
    });
  }
  return out;
}

async function collectCandidates(queries, type) {
  const seen = new Set(); const all = [];
  for (const q of queries) {
    const { text } = await get('https://www.themoviedb.org/search?query=' + encodeURIComponent(q) + '&language=ru-RU');
    for (const c of parseCards(text)) {
      const k = c.type + '/' + c.id;
      if (seen.has(k)) continue;
      seen.add(k); all.push(c);
    }
    await sleep(90);
    if (all.filter((c) => c.type === type).length >= 5) break;
  }
  return all;
}

async function resolve(type, ru, en, year) {
  const queries = [];
  if (en && en !== ru) queries.push(en);
  queries.push(ru);
  const cands = await collectCandidates(queries, type);
  const typed = cands.filter((c) => c.type === type);
  const pool = (typed.length ? typed : cands).slice(0, 8);
  if (!pool.length) return null;
  const rank = (c) => (c.year === year ? 0 : (c.year && Math.abs(c.year - year) <= 1 ? 1 : 2)) * 10 + (c.hasImage ? 0 : 5);
  const ranked = [...pool].sort((a, b) => rank(a) - rank(b)).slice(0, 3);

  let best = null;
  for (const c of ranked) {
    const d = await fetchDetails(c.type, c.id);
    const gotYear = d.date ? +d.date.slice(0, 4) : null;
    const votes = d.votesTmdb || 0;
    const nameSim = Math.max(sim(ru, d.title), sim(ru, d.originalTitle), sim(en, d.title), sim(en, d.originalTitle));
    const score = (gotYear === year ? 1000 : (gotYear && Math.abs(gotYear - year) <= 1 ? 400 : 0))
      + nameSim * 600
      + Math.min(votes, 200000) / 100 + (d.poster ? 30 : 0) + (d.description ? 20 : 0);
    if (!best || score > best.score) best = { cand: c, d, score, gotYear, votes };
    await sleep(80);
    if (gotYear === year && nameSim > 0.85 && d.poster) break;
  }
  return best;
}

async function kpIdsFor(ids, prop, prefix) {
  const map = {};
  const chunk = 100;
  for (let i = 0; i < ids.length; i += chunk) {
    const part = ids.slice(i, i + chunk);
    const q = `SELECT ?tmdb ?kp WHERE {
      VALUES ?tmdb { ${part.map((x) => `'${x}'`).join(' ')} }
      ?item wdt:${prop} ?tmdb.
      ?item wdt:P2603 ?kp.
    }`;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const r = await fetch('https://query.wikidata.org/sparql?format=json&query=' + encodeURIComponent(q), {
          headers: { 'User-Agent': WIKIDATA_UA, Accept: 'application/sparql-results+json' },
        });
        if (!r.ok) { await sleep(1500); continue; }
        const j = await r.json();
        for (const bb of j.results.bindings) {
          const t = prefix + '/' + bb.tmdb.value;
          (map[t] = map[t] || []).push(bb.kp.value);
        }
        break;
      } catch (e) { await sleep(1500); }
    }
    await sleep(400);
  }
  return map;
}

async function kpRating(kpId) {
  const { text } = await get(`https://rating.kinopoisk.ru/${kpId}.xml`, { 'User-Agent': UA }, 2);
  const m = text.match(/<kp_rating num_vote="(\d+)">([\d.]+)<\/kp_rating>/);
  const i = text.match(/<imdb_rating num_vote="(\d+)">([\d.]+)<\/imdb_rating>/);
  if (!m) return null;
  return { kpId: +kpId, kp: +m[2], kpVotes: +m[1], imdb: i ? +i[2] : null };
}

async function pool(items, worker, concurrency = 4) {
  const results = new Array(items.length);
  let idx = 0;
  await Promise.all(Array.from({ length: concurrency }, async () => {
    while (idx < items.length) { const i = idx++; results[i] = await worker(items[i], i); }
  }));
  return results;
}

// ---------- RUN ----------
const LIST = process.env.LIMIT ? TITLES.slice(0, +process.env.LIMIT) : TITLES;
const CACHE = 'tools/_cache_tmdb.json';
const cache = existsSync(CACHE) ? JSON.parse(readFileSync(CACHE, 'utf8')) : {};

console.log(`Шаг 1/3: TMDB — ${LIST.length} названий`);
let done = 0;
await pool(LIST, async ([type, ru, en, year]) => {
  const key = `${type}|${ru}|${en}|${year}`;
  if (key in cache) { done++; return cache[key]; }
  let rec = null;
  try {
    let hit;
    if (FORCE[ru]) {
      const f = FORCE[ru];
      hit = { cand: { id: f.id, type: f.type }, d: await fetchDetails(f.type, f.id), gotYear: year, votes: 0 };
    } else {
      hit = await resolve(type, ru, en, year);
    }
    if (hit && hit.d.title) {
      rec = { type, ru, en, ...hit.d };
      rec.year = Math.abs((hit.gotYear || year) - year) <= 1 ? year : hit.gotYear;
      if (Math.abs((hit.gotYear || year) - year) > 1) console.log(`  ⚠ год: ${ru} (${year}) -> ${rec.title} (${hit.gotYear}) tmdb ${hit.cand.id}`);
      if (!rec.poster) console.log('  ⚠ нет постера:', ru);
    } else {
      console.log('  ✗ не найдено:', ru);
    }
  } catch (e) { console.log('  ! ошибка', ru, e.message); }
  cache[key] = rec;
  done++;
  if (done % 15 === 0) { console.log(`  ... ${done}/${LIST.length}`); writeFileSync(CACHE, JSON.stringify(cache, null, 1)); }
  return rec;
}, 4);
writeFileSync(CACHE, JSON.stringify(cache, null, 1));

let items = LIST.map(([t, ru, en, y]) => cache[`${t}|${ru}|${en}|${y}`]).filter(Boolean);
const seenId = new Set();
items = items.filter((i) => { const k = i.type + '/' + i.tmdbId; if (seenId.has(k)) return false; seenId.add(k); return true; });
console.log(`  собрано: ${items.length}`);

console.log('Шаг 2/3: Wikidata → ID КиноПоиска');
const movieIds = [...new Set(items.filter((i) => i.type === 'movie').map((i) => String(i.tmdbId)))];
const tvIds = [...new Set(items.filter((i) => i.type === 'tv').map((i) => String(i.tmdbId)))];
const kpMovies = await kpIdsFor(movieIds, 'P4947', 'movie');
const kpTv = await kpIdsFor(tvIds, 'P4983', 'tv');
const kpMap = { ...kpMovies, ...kpTv };
console.log(`  связей: фильмы ${Object.keys(kpMovies).length}/${movieIds.length}, сериалы ${Object.keys(kpTv).length}/${tvIds.length}`);

console.log('Шаг 3/3: рейтинги КиноПоиска');
const need = [...new Set(Object.values(kpMap).flat())];
const ratings = {};
await pool(need, async (id) => { ratings[id] = await kpRating(id); await sleep(60); }, 4);
console.log(`  получено: ${need.filter((id) => ratings[id]).length}/${need.length}`);

for (const it of items) {
  const cands = (kpMap[it.type + '/' + it.tmdbId] || []).map((id) => ratings[id]).filter(Boolean).sort((a, b) => b.kpVotes - a.kpVotes);
  if (FORCE_KP[it.ru]) {
    const r = ratings[String(FORCE_KP[it.ru])] || await kpRating(FORCE_KP[it.ru]);
    if (r) { it.kinopoiskId = r.kpId; it.ratingKp = r.kp; it.votesKp = r.kpVotes; it.ratingImdb = r.imdb; }
  }
  if (cands.length && !it.ratingKp) {
    it.kinopoiskId = cands[0].kpId;
    it.ratingKp = cands[0].kp;
    it.votesKp = cands[0].kpVotes;
    it.ratingImdb = cands[0].imdb;
  }
}

writeFileSync('tools/_raw.json', JSON.stringify(items, null, 1));
console.log(`\nГотово. Всего: ${items.length}, с постером: ${items.filter((i) => i.poster).length}, с рейтингом КП: ${items.filter((i) => i.ratingKp).length}`);
