// Проверяет standalone-демо: один html-файл, без сервера, без Telegram и без сети
import { readFileSync, existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const here = dirname(fileURLToPath(import.meta.url));
const FILE = resolve(here, '..', '..', 'КиноФикация-ДЕМО.html');
if (!existsSync(FILE)) {
  console.error('Файл не найден:', FILE, '\nСначала выполните: node tools/make-demo.mjs');
  process.exit(1);
}
const HTML = readFileSync(FILE, 'utf8');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const dom = new JSDOM(HTML, { url: 'https://demo.local/', runScripts: 'dangerously', pretendToBeVisual: true });
const w = dom.window;
const errs = [];
w.addEventListener('error', (e) => errs.push(e.message));
w.confirm = () => true;
const netCalls = [];
w.fetch = async (u) => { netCalls.push(String(u)); throw new Error('сеть не должна вызываться: ' + u); };

for (let i = 0; i < 120; i++) { if (w.document.querySelector('#loader').classList.contains('off')) break; await sleep(25); }

let pass = 0, fail = 0;
const ck = (n, c, x) => { if (c) { pass++; console.log('  ✓', n); } else { fail++; console.log('  ✗', n, x !== undefined ? JSON.stringify(x).slice(0, 200) : ''); } };

console.log('\n=== ДЕМО-ФАЙЛ: один html, без сервера и без сети ===');
ck('загрузился без ошибок', errs.length === 0, errs);
ck('не сделал ни одного сетевого запроса', netCalls.length === 0, netCalls);
ck('загрузчик скрыт', w.document.querySelector('#loader').classList.contains('off'));
ck('каталог взят из файла (296)', w.KinoFik.state.catalog.length === 296, w.KinoFik.state.catalog.length);
ck('3 карточки отрисованы', w.document.querySelectorAll('#deck .card').length === 3);
ck('демо-режим включён', w.KinoFik.state.demo === true);
ck('демо-баннер виден', !w.document.querySelector('#demoBanner').classList.contains('hidden'));
ck('название на карточке', w.document.querySelector('.card-title').textContent.trim().length > 1);
ck('рейтинг на карточке', !!w.document.querySelector('.rate-badge b'));
ck('постер-тег есть', !!w.document.querySelector('.card-img'));

w.document.querySelector('.tab[data-screen="pair"]').click(); await sleep(50);
ck('экран «Пара» открывается', w.document.querySelector('#screen-pair').classList.contains('active'));
ck('в демо показывается пояснение', /Демо-режим/.test(w.document.querySelector('#pairStatus').textContent));
w.document.querySelector('.tab[data-screen="deck"]').click(); await sleep(40);

let matched = false;
for (let i = 0; i < 40 && !matched; i++) {
  w.document.querySelector('#btnYes').click(); await sleep(60);
  if (!w.document.querySelector('#matchOverlay').classList.contains('hidden')) matched = true;
}
ck('мэтч в демо срабатывает', matched);
ck('в оверлее честная подпись про демо', /Демо/.test(w.document.querySelector('#matchSub').textContent), w.document.querySelector('#matchSub').textContent);
ck('в оверлейке название фильма', w.document.querySelector('#matchTitle').textContent.length > 1, w.document.querySelector('#matchTitle').textContent);
w.document.querySelector('#matchOk').click(); await sleep(40);
ck('оверлей закрывается', w.document.querySelector('#matchOverlay').classList.contains('hidden'));

w.document.querySelector('.tab[data-screen="matches"]').click(); await sleep(60);
ck('мэтч попал в список', w.document.querySelectorAll('#matchList .mrow').length >= 1, w.document.querySelectorAll('#matchList .mrow').length);

w.document.querySelector('.tab[data-screen="deck"]').click(); await sleep(40);
w.document.querySelector('#typeSeg button[data-type="series"]').click(); await sleep(60);
ck('фильтр «Сериалы» работает', w.KinoFik.state.queue.length > 0 && w.KinoFik.state.queue.every((i) => i.type === 'series'));
w.document.querySelector('#typeSeg button[data-type="movie"]').click(); await sleep(60);
ck('фильтр «Фильмы» работает', w.KinoFik.state.queue.every((i) => i.type === 'movie'));
w.document.querySelector('#typeSeg button[data-type="all"]').click(); await sleep(60);

const chip = w.document.querySelector('.chip[data-genre="комедия"]');
chip.click(); await sleep(60);
ck('фильтр по жанру работает', w.KinoFik.state.queue.every((i) => i.genres.includes('комедия')));
chip.click(); await sleep(60);

const inp = w.document.querySelector('#searchInput');
inp.value = 'Интерстеллар'; inp.dispatchEvent(new w.Event('input')); await sleep(340);
ck('поиск находит «Интерстеллар»', w.KinoFik.state.queue[0] && w.KinoFik.state.queue[0].title === 'Интерстеллар', w.KinoFik.state.queue[0] && w.KinoFik.state.queue[0].title);
inp.value = ''; inp.dispatchEvent(new w.Event('input')); await sleep(340);

w.document.querySelector('#btnInfo').click(); await sleep(50);
ck('модалка открывается', !w.document.querySelector('#modal').classList.contains('hidden'));
ck('в модалке описание', w.document.querySelector('.m-desc').textContent.length > 40);
ck('в модалке рейтинги', w.document.querySelectorAll('.m-stats .stat').length >= 1);
w.document.querySelector('#modalClose').click(); await sleep(30);

// свайп жестом
const before = w.KinoFik.state.queue.length;
const card = w.document.querySelector('#deck .card');
const pe = (type, x, y) => { const e = new w.Event(type, { bubbles: true }); e.clientX = x; e.clientY = y; e.pointerId = 1; e.preventDefault = () => {}; card.dispatchEvent(e); };
pe('pointerdown', 200, 300); pe('pointermove', 340, 315); pe('pointerup', 340, 315);
await sleep(500);
ck('свайп вправо засчитан как лайк', w.KinoFik.state.queue.length === before - 1, [w.KinoFik.state.queue.length, before]);
ck('в истории — лайк', w.KinoFik.state.history[w.KinoFik.state.history.length - 1].dir === 1);

console.log(`\n════════ ДЕМО: ${pass} прошло, ${fail} упало ════════`);
process.exit(fail ? 1 : 0);
