// Локальная проверка серверной логики (мок Netlify Blobs + мок Telegram API)
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';

const TOKEN = 'TESTTOKEN:abc';
process.env.BOT_TOKEN = TOKEN;
process.env.URL = 'https://test-site.netlify.app';

const jsonResp = (o) => new Response(JSON.stringify(o), { status: 200, headers: { 'Content-Type': 'application/json' } });

const calls = [];
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, opts) => {
  const u = String(url);
  if (u.startsWith('https://api.telegram.org/')) {
    const method = u.split('/').pop();
    const body = opts && opts.body ? JSON.parse(opts.body) : {};
    calls.push({ method, body });
    if (method === 'getMe') {
      if (!u.includes('/bot' + encodeURIComponent(TOKEN) + '/') && !u.includes('/bot' + TOKEN + '/')) return jsonResp({ ok: false, description: 'Unauthorized' });
      return jsonResp({ ok: true, result: { id: 1, is_bot: true, username: 'kino_fik_bot', first_name: 'КиноФикация' } });
    }
    if (method === 'getWebhookInfo') return jsonResp({ ok: true, result: { url: process.env.URL + '/.netlify/functions/bot', pending_update_count: 0 } });
    return jsonResp({ ok: true, result: true });
  }
  if (u.includes('/data/movies.json')) return new Response(readFileSync('public/data/movies.json', 'utf8'), { status: 200, headers: { 'Content-Type': 'application/json' } });
  return realFetch(url, opts);
};

function makeInitData(user) {
  const p = {
    query_id: 'AAHdF6wAAAAAA6wXrBU',
    user: JSON.stringify(user),
    auth_date: String(Math.floor(Date.now() / 1000)),
    signature: crypto.randomBytes(32).toString('base64'),
  };
  const keys = Object.keys(p).sort();
  const dataCheckString = keys.map((k) => `${k}=${p[k]}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(TOKEN).digest();
  const hash = crypto.createHmac('sha256', secret).update(dataCheckString).digest('hex');
  const qs = new URLSearchParams();
  keys.forEach((k) => qs.set(k, p[k]));
  qs.set('hash', hash);
  return qs.toString();
}

const api = (await import('../netlify/functions/api.mjs')).default;
const bot = (await import('../netlify/functions/bot.mjs')).default;
const setup = (await import('../netlify/functions/setup.mjs')).default;

const A = { id: 111, first_name: 'Антон', username: 'anton' };
const B = { id: 222, first_name: 'Маша', username: 'masha' };
const initA = makeInitData(A);
const initB = makeInitData(B);

let pass = 0, fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓', name); }
  else { fail++; console.log('  ✗', name, extra !== undefined ? JSON.stringify(extra).slice(0, 400) : ''); }
}
async function post(a, payload) {
  const r = await a(new Request('https://test-site.netlify.app/api', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
  }));
  return { status: r.status, json: await r.json() };
}

const CATALOG = (await import('../netlify/functions/_catalog.mjs')).CATALOG;
const ids = Object.keys(CATALOG);
const M1 = ids[0], M2 = ids[1], M3 = ids[2];

console.log('\n=== 1. Авторизация ===');
let r = await post(api, { a: 'hello', initData: 'garbage' });
check('плохой initData отклонён', r.status === 401, r);
r = await post(api, { a: 'hello', initData: initA });
check('hello пользователя A', r.json.ok === true, r.json);
check('A получил код', /^[A-Z2-9]{5}$/.test(r.json.me.code || ''), r.json.me);
const codeA = r.json.me.code;
check('партнёра пока нет', r.json.partner === null, r.json);
check('пользователей: 1', r.json.users === 1, r.json.users);

console.log('\n=== 2. Авто-пара (ровно двое) ===');
r = await post(api, { a: 'hello', initData: initB });
check('hello пользователя B', r.json.ok === true, r.json);
check('B автоматически связан с A', r.json.partner && r.json.partner.id === '111', r.json.partner);
r = await post(api, { a: 'hello', initData: initA });
check('A теперь видит B', r.json.partner && r.json.partner.id === '222', r.json.partner);

console.log('\n=== 3. Голоса и мэтч ===');
calls.length = 0;
r = await post(api, { a: 'vote', initData: initA, id: M1, v: 1 });
check('A лайкнул ' + CATALOG[M1].t, r.json.ok === true && r.json.match === null, r.json);
r = await post(api, { a: 'vote', initData: initA, id: M2, v: -1 });
check('A дизлайкнул ' + CATALOG[M2].t, r.json.ok === true && r.json.match === null, r.json);
r = await post(api, { a: 'vote', initData: initB, id: M2, v: 1 });
check('B лайкнул то, что A отверг → мэтча нет', r.json.ok === true && r.json.match === null, r.json);
r = await post(api, { a: 'vote', initData: initB, id: M1, v: 1 });
check('B лайкнул то же, что A → МЭТЧ', r.json.ok === true && r.json.match && r.json.match.id === M1, r.json);
check('в мэтче два участника', r.json.match && r.json.match.by.length === 2, r.json.match);
check('название в мэтче', r.json.match && r.json.match.title === CATALOG[M1].t, r.json.match);

console.log('\n=== 4. Уведомления в Telegram ===');
const photos = calls.filter((c) => c.method === 'sendPhoto');
check('отправлено 2 уведомления (sendPhoto)', photos.length === 2, calls.map((c) => c.method));
check('уведомление ушло A', photos.some((c) => String(c.body.chat_id) === '111'), photos.map((c) => c.body.chat_id));
check('уведомление ушло B', photos.some((c) => String(c.body.chat_id) === '222'), photos.map((c) => c.body.chat_id));
check('в подписи есть «МЭТЧ»', photos[0] && /МЭТЧ/.test(photos[0].body.caption), photos[0] && photos[0].body.caption);
check('в подписи есть название', photos[0] && photos[0].body.caption.includes(CATALOG[M1].t), photos[0] && photos[0].body.caption);
check('есть inline-кнопки', photos[0] && photos[0].body.reply_markup.inline_keyboard[0].length === 2, photos[0] && photos[0].body.reply_markup);

console.log('\n=== 5. Повторный лайк не дублирует мэтч ===');
calls.length = 0;
r = await post(api, { a: 'vote', initData: initA, id: M1, v: 1 });
check('повторный лайк → match = null', r.json.ok === true && r.json.match === null, r.json);
check('новых уведомлений нет', calls.filter((c) => c.method === 'sendPhoto').length === 0, calls);
r = await post(api, { a: 'hello', initData: initA });
check('в списке ровно 1 мэтч', r.json.matches.length === 1, r.json.matches);
r = await post(api, { a: 'hello', initData: initB });
check('B видит тот же мэтч', r.json.matches.length === 1 && r.json.matches[0].id === M1, r.json.matches);

console.log('\n=== 6. Отмена голоса убирает мэтч ===');
r = await post(api, { a: 'unvote', initData: initA, id: M1 });
check('unvote прошёл', r.json.ok === true, r.json);
check('мэтч у A удалён', (r.json.matches || []).length === 0, r.json.matches);
r = await post(api, { a: 'hello', initData: initB });
check('мэтч у B тоже удалён', r.json.matches.length === 0, r.json.matches);

console.log('\n=== 7. Ручная связь по коду ===');
r = await post(api, { a: 'unpair', initData: initA });
check('unpair A', r.json.ok === true, r.json);
r = await post(api, { a: 'hello', initData: initA });
check('A больше не в паре', r.json.partner === null, r.json.partner);
r = await post(api, { a: 'pair', initData: initA, code: 'WRONG' });
check('неверный код отклонён', r.json.ok === false && /Такого кода/.test(r.json.error || ''), r.json);
r = await post(api, { a: 'hello', initData: initB });
const codeB = r.json.me.code;
r = await post(api, { a: 'pair', initData: initA, code: codeB.toLowerCase() });
check('связь по коду B (в нижнем регистре)', r.json.ok === true && r.json.partner.id === '222', r.json);
r = await post(api, { a: 'pair', initData: initA, code: codeA });
check('свой код отклонён', r.json.ok === false && /собственный/.test(r.json.error || ''), r.json);

console.log('\n=== 8. Отметка «посмотрели» и сброс ===');
await post(api, { a: 'vote', initData: initA, id: M3, v: 1 });
await post(api, { a: 'vote', initData: initB, id: M3, v: 1 });
r = await post(api, { a: 'watched', initData: initA, id: M3, v: true });
check('отметили просмотренным', r.json.ok === true && r.json.match && r.json.match.watched === true, r.json);
r = await post(api, { a: 'hello', initData: initB });
check('B видит watched=true', r.json.matches.some((m) => m.id === M3 && m.watched === true), r.json.matches);
r = await post(api, { a: 'reset', initData: initA });
check('reset A', r.json.ok === true && Object.keys(r.json.votes).length === 0, r.json);
r = await post(api, { a: 'hello', initData: initA });
check('после reset мэтчей нет', r.json.matches.length === 0, r.json.matches);

console.log('\n=== 9. Защита каталога ===');
r = await post(api, { a: 'vote', initData: initA, id: 'hacker', v: 1 });
check('левый id отклонён', r.status === 404, r);
r = await post(api, { a: 'nosuch', initData: initA });
check('неизвестное действие отклонено', r.status === 400, r);

console.log('\n=== 10. Вебхук бота ===');
calls.length = 0;
const botReq = (u) => bot(new Request('https://test-site.netlify.app/.netlify/functions/bot', {
  method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(u),
}));
await botReq({ message: { message_id: 1, chat: { id: 333, type: 'private' }, from: { id: 333, first_name: 'Тест' }, text: '/start', date: 1 } });
check('/start отвечает', calls.some((c) => c.method === 'sendMessage'), calls.map((c) => c.method));
const startMsg = calls.find((c) => c.method === 'sendMessage');
check('в /start есть клавиатура с web_app', !!(startMsg && startMsg.body.reply_markup && startMsg.body.reply_markup.keyboard[0][0].web_app), startMsg && startMsg.body.reply_markup);
check('web_app url корректный', startMsg.body.reply_markup.keyboard[0][0].web_app.url === 'https://test-site.netlify.app/', startMsg.body.reply_markup.keyboard[0][0]);
calls.length = 0;
await botReq({ message: { message_id: 2, chat: { id: 111, type: 'private' }, from: A, text: '/matches', date: 1 } });
check('/matches отвечает', calls.some((c) => c.method === 'sendMessage'), calls.map((c) => c.method));
calls.length = 0;
await botReq({ message: { message_id: 3, chat: { id: 444, type: 'private' }, from: { id: 444, first_name: 'Новая' }, text: '/start pair_' + codeB, date: 1 } });
check('/start pair_ связывает', calls.some((c) => c.method === 'sendMessage' && /Готово/.test(c.body.text || '')), calls.map((c) => (c.body.text || '').slice(0, 40)));
calls.length = 0;
await botReq({ message: { message_id: 4, chat: { id: 555, type: 'private' }, from: { id: 555, first_name: 'X' }, text: 'привет', date: 1 } });
check('обычный текст → подсказка', calls.some((c) => c.method === 'sendMessage'), calls.length);

console.log('\n=== 11. Setup ===');
delete process.env.BOT_TOKEN; // проверяем режим «токен в хранилище»
const setupReq = (init, body) => setup(new Request('https://test-site.netlify.app/setup', init, body));
calls.length = 0;
let sres = await setupReq({ method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ token: TOKEN }).toString() });
let shtml = await sres.text();
check('POST с токеном: токен сохранён', /Токен сохранён/.test(shtml));
check('getMe вызван', calls.some((c) => c.method === 'getMe'), calls.map((c) => c.method));
check('setWebhook вызван', calls.some((c) => c.method === 'setWebhook'), calls.map((c) => c.method));
const wh = calls.find((c) => c.method === 'setWebhook');
check('вебхук ведёт на /.netlify/functions/bot', wh && wh.body.url === 'https://test-site.netlify.app/.netlify/functions/bot', wh && wh.body);
check('setChatMenuButton вызван', calls.some((c) => c.method === 'setChatMenuButton'), calls.map((c) => c.method));
const mb = calls.find((c) => c.method === 'setChatMenuButton');
check('кнопка-меню = web_app на сайт', mb && mb.body.menu_button.type === 'web_app' && mb.body.menu_button.web_app.url === 'https://test-site.netlify.app/', mb && mb.body);
check('setMyCommands вызван', calls.some((c) => c.method === 'setMyCommands'), calls.map((c) => c.method));
check('ошибок на странице нет', !/class="row bad"/.test(shtml), shtml.match(/class="row bad"[\s\S]{0,220}/g));
check('зелёный баннер «Всё настроено»', /Всё настроено/.test(shtml));
check('каталог проверен', /296 фильмов и сериалов/.test(shtml), shtml.match(/Каталог на сайте[\s\S]{0,120}/));

// замена токена требует подтверждения
calls.length = 0;
sres = await setupReq({ method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ token: 'BAD:token' }).toString() });
shtml = await sres.text();
check('чужой токен без подтверждения не принимается', /замена отменена/i.test(shtml), shtml.match(/row bad[\s\S]{0,200}/));
sres = await setupReq({ method: 'GET' });
shtml = await sres.text();
check('GET работает без env-токена (берёт из хранилища)', /Результат настройки/.test(shtml) && /kino_fik_bot/.test(shtml));
check('токен из хранилища остался валидным', /Бот найден/.test(shtml));
process.env.BOT_TOKEN = TOKEN;

console.log(`\n════════ ИТОГ: ${pass} прошло, ${fail} упало ════════`);
process.exit(fail ? 1 : 0);
