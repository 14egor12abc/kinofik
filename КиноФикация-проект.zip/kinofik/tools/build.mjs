// Превращает tools/_raw.json в public/data/movies.json — каталог для приложения
import { readFileSync, writeFileSync } from 'node:fs';

const raw = JSON.parse(readFileSync('tools/_raw.json', 'utf8'));

const COUNTRY = {
  'Соединенные Штаты': 'США', 'США': 'США', 'Соединенные Штаты Америки': 'США',
  'Россия': 'Россия', 'Российская Федерация': 'Россия', 'СССР': 'СССР',
  'Великобритания': 'Великобритания', 'Англия': 'Великобритания',
  'Франция': 'Франция', 'Германия': 'Германия', 'ФРГ': 'Германия',
  'Италия': 'Италия', 'Испания': 'Испания', 'Канада': 'Канада', 'Австралия': 'Австралия',
  'Япония': 'Япония', 'Китай': 'Китай', 'Южная Корея': 'Корея', 'Республика Корея': 'Корея',
  'Индия': 'Индия', 'Бразилия': 'Бразилия', 'Мексика': 'Мексика', 'Швеция': 'Швеция',
  'Норвегия': 'Норвегия', 'Дания': 'Дания', 'Финляндия': 'Финляндия', 'Польша': 'Польша',
  'Нидерланды': 'Нидерланды', 'Бельгия': 'Бельгия', 'Швейцария': 'Швейцария',
  'Ирландия': 'Ирландия', 'Новая Зеландия': 'Новая Зеландия', 'Чехия': 'Чехия',
  'Украина': 'Украина', 'Казахстан': 'Казахстан', 'Беларусь': 'Беларусь', 'Турция': 'Турция',
  'Израиль': 'Израиль', 'Аргентина': 'Аргентина', 'Таиланд': 'Таиланд', 'Гонконг': 'Гонконг',
  'Австрия': 'Австрия', 'Португалия': 'Португалия', 'Венгрия': 'Венгрия', 'Румыния': 'Румыния',
  'Южно-Африканская Республика': 'ЮАР', 'ЮАР': 'ЮАР', 'Колумбия': 'Колумбия', 'Чили': 'Чили',
  'Исландия': 'Исландия', 'Греция': 'Греция', 'Сингапур': 'Сингапур', 'Индонезия': 'Индонезия',
  'Объединенные Арабские Эмираты': 'ОАЭ', 'Египет': 'Египет',
};

const AGE = {
  'G': '0+', 'PG': '6+', 'PG-13': '12+', 'R': '16+', 'NC-17': '18+', 'NR': '16+',
  'TV-Y': '0+', 'TV-Y7': '6+', 'TV-G': '0+', 'TV-PG': '6+', 'TV-14': '12+', 'TV-MA': '18+',
  '0+': '0+', '6+': '6+', '12+': '12+', '16+': '16+', '18+': '18+',
  'M18': '18+', 'R21': '18+', 'PG13': '12+', 'U': '6+', '12A': '12+', '15': '16+', '18': '18+',
};

const GENRE_FIX = {
  'нф': 'фантастика', 'научная фантастика': 'фантастика', 'sci-fi': 'фантастика',
  'боевик и приключения': 'боевик', 'приключенческий боевик': 'боевик',
  'телевик': null, 'кино о кино': null, 'новости': null, 'реалити': null,
  'детский': 'семейный', 'мыльная опера': 'мелодрама', 'разговорное': null,
  'аниме': 'мультфильм', 'анимационный': 'мультфильм', 'комедийный': 'комедия',
};

const cleanGenres = (g) => [...new Set(
  (g || [])
    .flatMap((x) => String(x).split(/\s+и\s+|\s*,\s*/i))
    .map((x) => x.trim().toLowerCase())
    .map((x) => (x in GENRE_FIX ? GENRE_FIX[x] : x))
    .filter((x) => x && x.length > 1)
)];

const clean = (s, n) => {
  if (!s) return null;
  s = String(s).replace(/\s+/g, ' ').trim();
  if (!s) return null;
  return n && s.length > n ? s.slice(0, n).replace(/[,;:\s][^,;:\s]*$/, '') + '…' : s;
};

const items = [];
for (const r of raw) {
  const isTv = r.type === 'tv';
  const kp = r.ratingKp ?? null;
  const tm = r.ratingTmdb != null ? Math.round(r.ratingTmdb * 10) / 10 : null;
  const rating = kp != null ? Math.round(kp * 10) / 10 : tm;
  const genres = cleanGenres(r.genres);
  const countries = [...new Set((r.countries || []).map((c) => COUNTRY[c] || c))].slice(0, 2);

  items.push({
    id: (isTv ? 's' : 'm') + r.tmdbId,
    type: isTv ? 'series' : 'movie',
    title: r.ru || r.title,
    alt: (r.title && r.title !== r.ru) ? r.title : (r.en || r.originalTitle || null),
    year: r.year || (r.date ? +r.date.slice(0, 4) : null),
    genres,
    country: countries.join(', ') || null,
    minutes: isTv ? null : (r.minutes || null),
    seasons: isTv ? (r.seasons || null) : null,
    episodes: isTv ? (r.episodes || null) : null,
    age: AGE[r.ageRating] || null,
    tagline: clean(r.tagline, 120),
    description: clean(r.description, 520),
    poster: r.poster || null,
    backdrop: r.backdrop || null,
    rating,
    src: kp != null ? 'kp' : (tm != null ? 'tmdb' : null),
    votes: kp != null ? (r.votesKp || 0) : (r.votesTmdb || 0),
    imdb: r.ratingImdb ?? null,
    kpId: r.kinopoiskId || null,
    tmdbId: r.tmdbId,
  });
}

// Стабильный порядок в файле: сначала фильмы, потом сериалы; внутри — по рейтингу
items.sort((a, b) => (b.rating || 0) - (a.rating || 0));

const out = {
  version: new Date().toISOString().slice(0, 10),
  source: 'Рейтинги — КиноПоиск, постеры и описания — TMDB',
  count: items.length,
  items,
};
writeFileSync('public/data/movies.json', JSON.stringify(out));

const g = {};
items.forEach((i) => i.genres.forEach((x) => { g[x] = (g[x] || 0) + 1; }));
console.log('Записей:', items.length,
  '| фильмы:', items.filter((i) => i.type === 'movie').length,
  '| сериалы:', items.filter((i) => i.type === 'series').length);
console.log('С рейтингом КП:', items.filter((i) => i.src === 'kp').length);
console.log('Жанров:', Object.keys(g).length, '→', Object.entries(g).sort((a, b) => b[1] - a[1]).slice(0, 18).map(([k, v]) => `${k}(${v})`).join(', '));
console.log('Размер файла:', (JSON.stringify(out).length / 1024).toFixed(0) + ' КБ');

/* ---- служебный мини-каталог для серверных функций (уведомления о мэтчах) ---- */
const mini = {};
for (const i of items) {
  mini[i.id] = { t: i.title, y: i.year, tp: i.type, p: i.poster, r: i.rating, s: i.src, g: i.genres };
}
const miniSrc = '// АВТОМАТИЧЕСКИ СОЗДАННЫЙ ФАЙЛ — не редактируйте вручную.\n'
  + '// Запустите: node tools/build.mjs\n'
  + `export const CATALOG = ${JSON.stringify(mini)};\n`;
writeFileSync('netlify/functions/_catalog.mjs', miniSrc);
console.log('catalog.mjs для функций:', (miniSrc.length / 1024).toFixed(0) + ' КБ,', Object.keys(mini).length, 'записей');
