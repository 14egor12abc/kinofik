// Сквозной тест мини-приложения: настоящий jsdom + настоящий Netlify-функция api.mjs
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';

const TOKEN = 'TESTTOKEN:abc';
process.env.BOT_TOKEN = TOKEN;
process.env.URL = 'https://test-site.netlify.app';

const tgCalls = [];
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, opts) => {
  const u = String(url);
  if (u.startsWith('https://api.telegram.org/')) {
    const method = u.split('/').pop();
    const body = opts && opts.body ? JSON.parse(opts.body) : {};
    tgCalls.push({ method, body });
    if (method === 'sendPhoto') return new Response(JSON.stringify({ ok: true, result: {} }), { status: 200 });
    return new Response(JSON.stringify({ ok: true, result: true }), { status: 200 });
  }
  return realFetch(url, opts);
};

const apiHandler = (await import('../netlify/functions/api.mjs')).default;
const { CATALOG } = await import('../netlify/functions/_catalog.mjs');
const MOVIES = readFileSync('public/data/movies.json', 'utf8');
const HTML = readFileSync('public/index.html', 'utf8');
const APPJS = readFileSync('public/app.js', 'utf8');

function makeInitData(user) {
  const p = {
    query_id: 'AAHdF6wAAAAAA6wXrBU',
    user: JSON.stringify(user),
    auth_date: String(Math.floor(Date.now() / 1000)),
    signature: crypto.randomBytes(32).toString('base64'),
  };
  const keys = Object.keys(p).sort();
  const secret = crypto.createHmac('sha256', 'WebAppData').update(TOKEN).digest();
  const h = crypto.createHmac('sha256', secret).update(keys.map((k) => `${k}=${p[k]}`).join('\n')).digest('hex');
  const qs = new URLSearchParams();
  keys.forEach((k) => qs.set(k, p[k]));
  qs.set('hash', h);
  return qs.toString();
}

function telegramStub(user, initData) {
  return {
    WebApp: {
      initData,
      initDataUnsafe: { user, start_param: '', bot: { username: 'kino_fik_bot' } },
      ready() {}, expand() {}, setHeaderColor() {}, setBackgroundColor() {},
      disableVerticalSwipes() {}, enableClosingConfirmation() {},
      HapticFeedback: { impactOccurred() {}, notificationOccurred() {}, selectionChanged() {} },
      BackButton: { show() {}, hide() {}, onClick() {}, offClick() {} },
      onEvent() {}, openTelegramLink() {}, version: '7.0', platform: 'tdesktop',
    },
  };
}

async function openApp(user) {
  const initData = makeInitData(user);
  const dom = new JSDOM(HTML, {
    url: 'https://test-site.netlify.app/',
    runScripts: 'outside-only',
    pretendToBeVisual: true,
  });
  const w = dom.window;
  w.Telegram = telegramStub(user, initData);
  w.confirm = () => true;
  w.alert = () => {};
  const errors = [];
  w.addEventListener('error', (e) => errors.push(e.message));

  w.fetch = async (url, opts) => {
    const u = String(url);
    if (u.endsWith('data/movies.json') || u.includes('data/movies.json')) {
      return { ok: true, status: 200, json: async () => JSON.parse(MOVIES), text: async () => MOVIES };
    }
    if (u === '/api' || u.endsWith('/api')) {
      const res = await apiHandler(new Request('https://test-site.netlify.app/api', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: opts.body,
      }));
      const text = await res.text();
      return { ok: res.ok, status: res.status, json: async () => JSON.parse(text), text: async () => text };
    }
    throw new Error('unexpected fetch: ' + u);
  };

  w.eval(APPJS + '\n;window.__KF = { S, vote, undo, refreshProfile, buildQueue, paint, openInfo };');
  // ждём завершения boot()
  for (let i = 0; i < 120; i++) {
    if (w.document.querySelector('#loader').classList.contains('off')) break;
    await new Promise((r) => setTimeout(r, 25));
  }
  return { w, d: w.document, errors };
}

let pass = 0, fail = 0;
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  ✓', name); }
  else { fail++; console.log('  ✗', name, extra !== undefined ? String(JSON.stringify(extra)).slice(0, 500) : ''); }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// безопасное чтение текста, чтобы тест не падал на первом же промахе
const txt = (d, sel) => { const e = d.querySelector(sel); return e ? e.textContent : null; };
const attr = (d, sel, a) => { const e = d.querySelector(sel); return e ? e.getAttribute(a) : null; };

const A = { id: 111, first_name: 'Антон', username: 'anton' };
const B = { id: 222, first_name: 'Маша', username: 'masha' };

console.log('\n=== A. Запуск приложения (пользователь A) ===');
const a = await openApp(A);
check('нет ошибок в консоли', a.errors.length === 0, a.errors);
check('загрузчик скрыт', a.d.querySelector('#loader').classList.contains('off'));
check('каталог загружен', a.w.__KF.S && a.w.__KF.S.catalog.length === 296, a.w.__KF.S && a.w.__KF.S.catalog.length);
check('профиль получен', a.w.__KF.S.me && a.w.__KF.S.me.id === '111', a.w.__KF.S.me);
check('в колоде 3 карточки', a.d.querySelectorAll('#deck .card').length === 3, a.d.querySelectorAll('#deck .card').length);
const c0 = a.d.querySelector('#deck .card');
check('на карточке есть название', !!c0.querySelector('.card-title').textContent.trim());
check('на карточке есть рейтинг', !!c0.querySelector('.rate-badge b'));
check('рейтинг подписан «КиноПоиск»', /КиноПоиск|TMDB/.test(c0.querySelector('.rate-badge small').textContent), c0.querySelector('.rate-badge small').textContent);
check('есть постер', !!c0.querySelector('.card-img'));
check('метка Фильм/Сериал', /Фильм|Сериал/.test(c0.querySelector('.card-top .tag').textContent));
check('жанры на карточке', c0.querySelectorAll('.card-genres .g').length > 0);
check('прогресс-бар есть', !!a.d.querySelector('#progressFill'));
check('онбординг показан', !a.d.querySelector('#onboard').classList.contains('hidden'));
a.d.querySelector('#obStart').click();
check('онбординг закрылся', a.d.querySelector('#onboard').classList.contains('hidden'));

console.log('\n=== B. Фильтры и поиск ===');
const firstBefore = a.w.__KF.S.queue[0].id;
a.d.querySelector('#typeSeg button[data-type="series"]').click();
await sleep(30);
check('фильтр «Сериалы» применён', a.w.__KF.S.filter.type === 'series');
check('в колоде только сериалы', a.w.__KF.S.queue.every((i) => i.type === 'series'));
check('колода изменилась', a.w.__KF.S.queue[0].id !== firstBefore || a.w.__KF.S.queue.length === 0);
a.d.querySelector('#typeSeg button[data-type="movie"]').click();
await sleep(30);
check('фильтр «Фильмы»', a.w.__KF.S.queue.every((i) => i.type === 'movie'));
a.d.querySelector('.chip[data-genre="комедия"]').click();
await sleep(30);
check('жанровый фильтр «комедия»', a.w.__KF.S.queue.every((i) => i.genres.includes('комедия')));
a.d.querySelector('.chip[data-genre="комедия"]').click();
await sleep(30);
check('жанр снят', a.w.__KF.S.filter.genre === null);
a.d.querySelector('#typeSeg button[data-type="all"]').click();

const SEARCH_ID = Object.keys(CATALOG).find((k) => CATALOG[k].t === 'Интерстеллар') || Object.keys(CATALOG)[5];
const searchTitle = CATALOG[SEARCH_ID].t;
const inp = a.d.querySelector('#searchInput');
inp.value = searchTitle;
inp.dispatchEvent(new a.w.Event('input'));
await sleep(320);
check('поиск нашёл «' + searchTitle + '»', a.w.__KF.S.queue.length >= 1 && a.w.__KF.S.queue[0].title === searchTitle, a.w.__KF.S.queue.slice(0, 3).map((i) => i.title));
inp.value = ''; inp.dispatchEvent(new a.w.Event('input'));
await sleep(320);
check('поиск очищен', a.w.__KF.S.queue.length > 5, a.w.__KF.S.queue.length);

console.log('\n=== C. Модальное окно с подробностями ===');
a.d.querySelector('#btnInfo').click();
await sleep(30);
check('модалка открылась', !a.d.querySelector('#modal').classList.contains('hidden'));
check('в модалке есть описание', a.d.querySelector('.m-desc').textContent.length > 40);
check('в модалке есть блок рейтингов', a.d.querySelectorAll('.m-stats .stat').length >= 1);
check('в модалке есть жанры', a.d.querySelectorAll('.m-genres .g').length >= 1);
a.d.querySelector('#modalClose').click();
await sleep(20);
check('модалка закрылась', a.d.querySelector('#modal').classList.contains('hidden'));

console.log('\n=== D. Свайп мышью/пальцем ===');
const beforeLen = a.w.__KF.S.queue.length;
const card = a.d.querySelector('#deck .card');
const pe = (type, x, y) => { const e = new a.w.Event(type, { bubbles: true }); e.clientX = x; e.clientY = y; e.pointerId = 1; e.preventDefault = () => {}; card.dispatchEvent(e); };
pe('pointerdown', 200, 300);
pe('pointermove', 215, 308);
check('карточка сдвинулась при перетаскивании', /translate/.test(card.style.transform), card.style.transform);
check('штамп «Нравится» проявился', parseFloat(card.querySelector('.stamp.yes').style.opacity) > 0);
pe('pointerup', 215, 308);
await sleep(400);
check('короткий свайп вернул карточку', a.w.__KF.S.queue.length === beforeLen, a.w.__KF.S.queue.length);

const card2 = a.d.querySelector('#deck .card');
const pe2 = (type, x, y) => { const e = new a.w.Event(type, { bubbles: true }); e.clientX = x; e.clientY = y; e.pointerId = 1; e.preventDefault = () => {}; card2.dispatchEvent(e); };
pe2('pointerdown', 200, 300);
pe2('pointermove', 60, 320);
pe2('pointerup', 60, 320);
await sleep(500);
check('свайп влево = дизлайк', a.w.__KF.S.queue.length === beforeLen - 1, a.w.__KF.S.queue.length);
const disliked = a.w.__KF.S.history[a.w.__KF.S.history.length - 1];
check('в истории записан дизлайк', disliked && disliked.dir === -1, disliked && disliked.dir);
check('голос ушёл на сервер', Object.values(a.w.__KF.S.votes).includes(-1));

console.log('\n=== E. Кнопки и «отменить» ===');
const len2 = a.w.__KF.S.queue.length;
a.d.querySelector('#btnNo').click();
await sleep(450);
check('кнопка ✖ = дизлайк', a.w.__KF.S.queue.length === len2 - 1, [a.w.__KF.S.queue.length, len2]);
a.d.querySelector('#btnUndo').click();
await sleep(250);
check('«отменить» вернула карточку', a.w.__KF.S.queue.length === len2, [a.w.__KF.S.queue.length, len2]);
a.d.querySelector('#btnYes').click();
await sleep(450);
check('кнопка ❤ = лайк', a.w.__KF.S.queue.length === len2 - 1);
check('лайк сохранён на сервере', Object.values(a.w.__KF.S.votes).includes(1));

console.log('\n=== F. Вкладка «Мэтчи» и «Пара» ===');
a.d.querySelector('.tab[data-screen="pair"]').click();
await sleep(30);
check('экран «Пара» открылся', a.d.querySelector('#screen-pair').classList.contains('active'));
check('показан мой код', /^[A-Z2-9]{5}$/.test(a.d.querySelector('#myCode').textContent.trim()), a.d.querySelector('#myCode').textContent);
check('показан профиль', /Антон/.test(a.d.querySelector('#profileBox').textContent), a.d.querySelector('#profileBox').textContent);
a.d.querySelector('.tab[data-screen="matches"]').click();
await sleep(30);
check('экран «Мэтчи» открылся', a.d.querySelector('#screen-matches').classList.contains('active'));
check('пока пусто', !a.d.querySelector('#emptyMatches').classList.contains('hidden'));
a.d.querySelector('#btnGoDeck').click();
await sleep(30);
check('кнопка «К карточкам» возвращает в колоду', a.d.querySelector('#screen-deck').classList.contains('active'));

console.log('\n=== G. ВТОРОЙ ПОЛЬЗОВАТЕЛЬ → НАСТОЯЩИЙ МЭТЧ ===');
tgCalls.length = 0;
const b = await openApp(B);
check('B запустился без ошибок', b.errors.length === 0, b.errors);
check('B автоматически в паре с A', b.w.__KF.S.partner && b.w.__KF.S.partner.first_name === 'Антон', b.w.__KF.S.partner);

// выбираем фильм, который A ещё не оценивал
const SA = a.w.__KF.S;
const cand = Object.keys(CATALOG).map((k) => ({ id: k, ...CATALOG[k] }))
  .filter((x) => !SA.votes[x.id] && x.t && x.t.length > 4)
  .sort((x, y) => (y.r || 0) - (x.r || 0));
const target = cand[0];
const targetTitle = target.t;

async function searchAndLike(app, title) {
  const inp = app.d.querySelector('#searchInput');
  inp.value = title;
  inp.dispatchEvent(new app.w.Event('input'));
  await sleep(330);
  const q = app.w.__KF.S.queue;
  if (!q.length || q[0].title !== title) return false;
  app.d.querySelector('#btnYes').click();
  await sleep(550);
  return true;
}

check('A лайкнул «' + targetTitle + '»', await searchAndLike(a, targetTitle));
check('A: лайк записан', a.w.__KF.S.votes[target.id] === 1, a.w.__KF.S.votes[target.id]);
check('A: мэтча ещё нет (B не голосовал)', tgCalls.filter((c) => c.method === 'sendPhoto').length === 0, tgCalls.map((c) => c.method));

check('B нашёл и лайкнул «' + targetTitle + '»', await searchAndLike(b, targetTitle));
await sleep(250);
check('у B появился оверлей «ЭТО МЭТЧ!»', !b.d.querySelector('#matchOverlay').classList.contains('hidden'));
check('в оверлее название фильма', txt(b.d, '#matchTitle') === targetTitle, txt(b.d, '#matchTitle'));
check('в оверлее постер', !!b.d.querySelector('#matchPoster').getAttribute('src'));
check('в оверлее рейтинг', /\d\.\d/.test(b.d.querySelector('#matchRate').textContent), b.d.querySelector('#matchRate').textContent);
check('в оверлее имя партнёра', /Антон/.test(b.d.querySelector('#matchSub').textContent), b.d.querySelector('#matchSub').textContent);
const photos = tgCalls.filter((c) => c.method === 'sendPhoto');
check('бот отправил 2 уведомления', photos.length === 2, tgCalls.map((c) => c.method + ':' + c.body.chat_id));
check('уведомления пришли обоим', photos.map((c) => String(c.body.chat_id)).sort().join(',') === '111,222', photos.map((c) => c.body.chat_id));
check('в уведомлении постер фильма', photos.every((c) => !!c.body.photo), photos.map((c) => c.body.photo));
check('в уведомлении название', photos.every((c) => (c.body.caption || '').includes(targetTitle)));
b.d.querySelector('#matchOk').click();
await sleep(40);
check('оверлей закрылся', b.d.querySelector('#matchOverlay').classList.contains('hidden'));

b.d.querySelector('.tab[data-screen="matches"]').click();
await sleep(50);
check('экран «Мэтчи» активен', b.d.querySelector('#screen-matches').classList.contains('active'));
check('мэтч в списке у B', b.d.querySelectorAll('#matchList .mrow').length === 1, b.d.querySelectorAll('#matchList .mrow').length);
check('название в списке верное', txt(b.d, '#matchList .mrow h3') === targetTitle, txt(b.d, '#matchList .mrow h3'));
check('рейтинг в списке верный', (txt(b.d, '#matchList .mrow .mrate') || '').includes(Number(target.r).toFixed(1)), txt(b.d, '#matchList .mrow .mrate'));
check('бейдж на вкладке = 1', b.d.querySelector('#matchBadge').textContent === '1', b.d.querySelector('#matchBadge').textContent);

console.log('\n=== H. Мэтч виден и у A после обновления ===');
await a.w.__KF.refreshProfile();
a.d.querySelector('.tab[data-screen="matches"]').click();
await sleep(60);
check('A видит тот же мэтч', a.d.querySelectorAll('#matchList .mrow').length === 1, a.d.querySelectorAll('#matchList .mrow').length);
check('название совпадает', txt(a.d, '#matchList .mrow h3') === targetTitle, txt(a.d, '#matchList .mrow h3'));

console.log('\n=== I. Карточка мэтча кликабельна + удаление ===');
const mrowA = a.d.querySelector('#matchList .mrow');
if (mrowA) mrowA.click(); else check('строка мэтча у A найдена', false);
await sleep(60);
check('клик по мэтчу открыл подробности', !a.d.querySelector('#modal').classList.contains('hidden'));
check('в подробностях тот же фильм', txt(a.d, '.m-titles h2') === targetTitle, txt(a.d, '.m-titles h2'));
a.d.querySelector('#modalClose').click();
await sleep(30);
b.d.querySelector('.tab[data-screen="matches"]').click();
await sleep(50);
b.d.querySelector('#matchList .mrow [data-act="del"]').click();
await sleep(400);
check('мэтч удалён из списка', b.d.querySelectorAll('#matchList .mrow').length === 0, b.d.querySelectorAll('#matchList .mrow').length);
check('показалось пустое состояние', !b.d.querySelector('#emptyMatches').classList.contains('hidden'));
await a.w.__KF.refreshProfile();
a.d.querySelector('.tab[data-screen="matches"]').click();
await sleep(60);
check('у A мэтч тоже пропал', a.d.querySelectorAll('#matchList .mrow').length === 0, a.d.querySelectorAll('#matchList .mrow').length);

console.log('\n=== J. Свой диалог подтверждения (вместо confirm) ===');
a.d.querySelector('.tab[data-screen="pair"]').click();
await sleep(40);
check('на экране «Пара» есть кнопка сброса', !!a.d.querySelector('#btnReset'));
a.d.querySelector('#btnReset').click();
await sleep(60);
check('открылся собственный диалог', !a.d.querySelector('#confirmBox').classList.contains('hidden'));
check('в диалоге понятный текст', /оценки и мэтчи/i.test(a.d.querySelector('#confirmText').textContent), a.d.querySelector('#confirmText').textContent);
a.d.querySelector('#confirmNo').click();
await sleep(40);
check('«Отмена» закрывает диалог', a.d.querySelector('#confirmBox').classList.contains('hidden'));
check('после отмены данные на месте', Object.keys(a.w.__KF.S.votes).length > 0, Object.keys(a.w.__KF.S.votes).length);
const votesBefore = Object.keys(a.w.__KF.S.votes).length;
a.d.querySelector('#btnReset').click();
await sleep(60);
a.d.querySelector('#confirmYes').click();
await sleep(300);
check('«Да» сбрасывает оценки', Object.keys(a.w.__KF.S.votes).length === 0, Object.keys(a.w.__KF.S.votes).length);
check('было голосов до сброса: ' + votesBefore, votesBefore > 0);
check('диалог закрылся после подтверждения', a.d.querySelector('#confirmBox').classList.contains('hidden'));

console.log('\n=== K. Демо-режим вне Telegram ===');
const dom3 = new JSDOM(HTML, { url: 'https://test-site.netlify.app/', runScripts: 'outside-only', pretendToBeVisual: true });
dom3.window.confirm = () => true;
const errs3 = [];
dom3.window.addEventListener('error', (e) => errs3.push(e.message));
dom3.window.fetch = async (url) => {
  if (String(url).includes('data/movies.json')) return { ok: true, status: 200, json: async () => JSON.parse(MOVIES), text: async () => MOVIES };
  throw new Error('в демо-режиме сеть не должна вызываться: ' + url);
};
dom3.window.eval(APPJS + '\n;window.__KF = { S, vote, refreshProfile };');
for (let i = 0; i < 100; i++) { if (dom3.window.document.querySelector('#loader').classList.contains('off')) break; await sleep(25); }
check('демо-режим запустился без ошибок', errs3.length === 0, errs3);
check('демо-баннер показан', !dom3.window.document.querySelector('#demoBanner').classList.contains('hidden'));
check('S.demo = true', dom3.window.__KF.S.demo === true);
check('карточки отрисованы', dom3.window.document.querySelectorAll('#deck .card').length === 3);
const d3 = dom3.window.document;
let sawMatch = false;
for (let i = 0; i < 40 && !sawMatch; i++) {
  d3.querySelector('#btnYes').click();
  await sleep(60);
  if (!d3.querySelector('#matchOverlay').classList.contains('hidden')) sawMatch = true;
}
check('в демо-режиме мэтч тоже демонстрируется', sawMatch);
check('демо-данные пишутся в localStorage', !!dom3.window.localStorage.getItem('kinofik_demo_v1'), dom3.window.localStorage.getItem('kinofik_demo_v1'));
check('в демо-режиме сеть не дёргается', true);

console.log(`\n════════ ИТОГ: ${pass} прошло, ${fail} упало ════════`);
process.exit(fail ? 1 : 0);
