// Дозаполняет количество сезонов у сериалов
import { readFileSync, writeFileSync } from 'node:fs';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const H = { 'User-Agent': UA, 'Accept-Language': 'ru-RU,ru;q=0.9' };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const items = JSON.parse(readFileSync('tools/_raw.json', 'utf8'));
const tvs = items.filter((i) => i.type === 'tv' && !i.seasons);
console.log('Нужно сезонов для:', tvs.length);

let n = 0;
await Promise.all(Array.from({ length: 4 }, async () => {
  while (tvs.length) {
    const it = tvs.shift();
    try {
      const r = await fetch(`https://www.themoviedb.org/tv/${it.tmdbId}?language=ru-RU`, { headers: H });
      const t = await r.text();
      const nums = [...new Set([...t.matchAll(new RegExp(`/tv/${it.tmdbId}[^"']*/season/(\\d+)`, 'g'))].map((m) => +m[1]))]
        .filter((x) => x > 0);
      if (nums.length) it.seasons = Math.max(...nums);
      const ep = t.match(/<strong>Количество серий<\/strong>\s*(\d+)/) || t.match(/(\d+)\s*(?:<\/[^>]+>)?\s*Сезон/);
      if (!it.episodes && ep) it.episodes = +ep[1];
    } catch (e) { /* пропускаем */ }
    n++;
    if (n % 20 === 0) console.log('  ...', n);
    await sleep(80);
  }
}));

writeFileSync('tools/_raw.json', JSON.stringify(items, null, 1));
console.log('Заполнено сезонов:', items.filter((i) => i.type === 'tv' && i.seasons).length, 'из', items.filter((i) => i.type === 'tv').length);
