// Собирает ОДИН html-файл со всем приложением и каталогом внутри.
// Его можно просто открыть двойным щелчком в браузере — без сервера и без Telegram.
import { readFileSync, writeFileSync } from 'node:fs';

const html = readFileSync('public/index.html', 'utf8');
const css = readFileSync('public/style.css', 'utf8');
const js = readFileSync('public/app.js', 'utf8');
const catalog = readFileSync('public/data/movies.json', 'utf8');

// защита от случайного закрытия тега внутри строки
const safe = (s) => s.replace(/<\/script/gi, '<\\/script').replace(/<\/style/gi, '<\\/style');

let out = html;

// 1) стили — внутрь
out = out.replace('<link rel="stylesheet" href="style.css">', () => `<style>\n${safe(css)}\n</style>`);

// 2) telegram-web-app.js не нужен: вне Telegram приложение само переходит в демо-режим
out = out.replace(/\s*<script src="https:\/\/telegram\.org\/js\/telegram-web-app\.js"><\/script>/, () => '');

// 3) скрипт + каталог — внутрь
out = out.replace('<script src="app.js"></script>',
  () => `<script>window.__CATALOG__ = ${safe(catalog)};</script>\n<script>\n${safe(js)}\n</script>`);

// 4) пометим, что это демо-сборка
out = out.replace('<title>КиноФикация — что смотрим сегодня?</title>',
  () => '<title>КиноФикация — ДЕМО (один файл, без сервера)</title>');
out = out.replace('<div id="demoBanner" class="hidden">Демо-режим: откройте через бота в Telegram, чтобы мэтчи работали по-настоящему</div>',
  () => '<div id="demoBanner" class="hidden">🧪 Демо-версия одним файлом: свайпы, фильтры и мэтчи работают, но партнёр имитируется. Настоящие мэтчи и уведомления — внутри бота @kino_fik_bot</div>');

writeFileSync('../КиноФикация-ДЕМО.html', out);

const kb = (n) => (n / 1024).toFixed(0) + ' КБ';
console.log('Готово: КиноФикация-ДЕМО.html');
console.log('  размер:', kb(out.length));
console.log('  внутри: стили', kb(css.length), '+ логика', kb(js.length), '+ каталог', kb(catalog.length));
console.log('  фильмов и сериалов:', JSON.parse(catalog).count);
