// Общие helpers для всех функций
import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';
import { BOT_TOKEN_FALLBACK, BOT_USERNAME, MENU_TEXT } from './_config.mjs';

export { BOT_USERNAME, MENU_TEXT };

export const STORE_NAME = 'kinofik';
let _store = null;
// ленивая инициализация, чтобы функция не падала на этапе импорта
export const db = () => (_store || (_store = getStore(STORE_NAME)));

/* ---------- конфигурация (токен бота) ---------- */
export async function getConfig() {
  const env = (process.env.BOT_TOKEN || '').trim();
  if (env) return { token: env, source: 'env' };
  try {
    const stored = await db().get('config:token');
    if (stored && stored.trim()) return { token: stored.trim(), source: 'store' };
  } catch (e) { /* ignore */ }
  if (BOT_TOKEN_FALLBACK) return { token: BOT_TOKEN_FALLBACK, source: 'fallback' };
  return { token: '', source: null };
}

export const SOURCE_LABEL = {
  env: 'переменной окружения BOT_TOKEN',
  store: 'защищённого хранилища Netlify (задан через /setup)',
  fallback: 'файла netlify/functions/_config.mjs (токен вписан заранее)',
};

/* ---------- полная настройка бота: вебхук + кнопка + команды ---------- */
export const BOT_COMMANDS = [
  { command: 'matches', description: '🍿 Наши мэтчи' },
  { command: 'code', description: '👥 Мой код для пары' },
  { command: 'pair', description: '💞 Связаться с партнёром' },
  { command: 'reset', description: '🧹 Сбросить мои оценки' },
  { command: 'help', description: '❓ Как это работает' },
];

export async function runSetup(token, site) {
  const out = [];
  const webhookUrl = site + '/.netlify/functions/bot';
  const appUrl = site + '/';

  const me = await tg('getMe', {}, token);
  if (!me.ok) {
    out.push({ ok: false, step: 'Проверка токена', text: me.description || 'Токен недействителен' });
    return { results: out, bot: null };
  }
  out.push({ ok: true, step: 'Бот найден', text: `@${me.result.username} · «${me.result.first_name}»` });

  const wh = await tg('setWebhook', {
    url: webhookUrl, allowed_updates: ['message', 'callback_query'], max_connections: 40,
  }, token);
  out.push({ ok: !!wh.ok, step: 'Вебхук (бот получает сообщения)', text: wh.ok ? webhookUrl : (wh.description || 'ошибка') });

  const mb = await tg('setChatMenuButton', {
    menu_button: { type: 'web_app', text: MENU_TEXT, web_app: { url: appUrl } },
  }, token);
  out.push({ ok: !!mb.ok, step: 'Кнопка слева от поля ввода', text: mb.ok ? `«${MENU_TEXT}»` : (mb.description || 'ошибка') });

  const cmds = await tg('setMyCommands', { commands: BOT_COMMANDS }, token);
  out.push({ ok: !!cmds.ok, step: 'Список команд', text: cmds.ok ? BOT_COMMANDS.map((c) => '/' + c.command).join(' ') : (cmds.description || 'ошибка') });

  const info = await tg('getWebhookInfo', {}, token);
  if (info.ok && info.result) {
    const r = info.result;
    out.push({
      ok: r.url === webhookUrl && !r.last_error_message,
      step: 'Статус вебхука',
      text: r.last_error_message
        ? `ошибка: ${r.last_error_message}`
        : `активен, обновлений в очереди: ${r.pending_update_count || 0}`,
    });
  }

  try {
    const probe = await fetch(site + '/data/movies.json');
    if (probe.ok) {
      const j = await probe.json();
      out.push({ ok: true, step: 'Каталог на сайте', text: `${j.count} фильмов и сериалов` });
    } else {
      out.push({ ok: false, step: 'Каталог на сайте', text: 'файл /data/movies.json не найден' });
    }
  } catch (e) {
    out.push({ ok: false, step: 'Каталог на сайте', text: 'не удалось проверить: ' + e.message });
  }

  return { results: out, bot: me.result };
}

export function siteUrl(req) {
  const u = (process.env.URL || process.env.DEPLOY_PRIME_URL || '').trim();
  if (u) return u.replace(/\/$/, '');
  const host = req && req.headers && (req.headers.get ? req.headers.get('host') : req.headers.host);
  return host ? 'https://' + host : '';
}

/* ---------- Telegram Bot API ---------- */
export async function tg(method, params, token) {
  const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params || {}),
  });
  let j = null;
  try { j = await r.json(); } catch (e) { j = { ok: false, error: 'bad response' }; }
  return j;
}

/* ---------- проверка initData из Mini App ---------- */
export function parseInitData(initData, token) {
  if (!initData || !token) return null;
  try {
    const p = new URLSearchParams(initData);
    const hash = p.get('hash');
    if (!hash) return null;
    p.delete('hash');
    const pairs = [...p.entries()].map(([k, v]) => `${k}=${v}`).sort();
    const secret = crypto.createHmac('sha256', 'WebAppData').update(token).digest();
    const calc = crypto.createHmac('sha256', secret).update(pairs.join('\n')).digest('hex');
    if (calc !== hash) return null;

    const authDate = Number(p.get('auth_date') || 0);
    // защита от повтора: не старше 24 часов
    if (authDate && Date.now() / 1000 - authDate > 86400) return null;

    const user = JSON.parse(p.get('user') || 'null');
    if (!user || !user.id) return null;
    return user;
  } catch (e) { return null; }
}

/* ---------- хранилище пользователей ---------- */
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // без похожих символов
export function genCode() {
  let s = '';
  const b = crypto.randomBytes(6);
  for (let i = 0; i < 5; i++) s += ALPHABET[b[i] % ALPHABET.length];
  return s;
}

export async function getUser(id) {
  const raw = await db().get('u:' + id);
  return raw ? JSON.parse(raw) : null;
}

export async function allUserIds() {
  const raw = await db().get('users:index');
  return raw ? JSON.parse(raw) : [];
}

export async function ensureUser(tgUser) {
  const id = String(tgUser.id);
  let u = await getUser(id);
  const index = await allUserIds();
  if (!u) {
    let code = genCode();
    for (let i = 0; i < 8; i++) {
      if (!(await db().get('c:' + code))) break;
      code = genCode();
    }
    u = {
      id,
      code,
      first_name: tgUser.first_name || '',
      last_name: tgUser.last_name || '',
      username: tgUser.username || '',
      photo_url: tgUser.photo_url || '',
      partnerId: null,
      created: Date.now(),
    };
    await db().set('u:' + id, JSON.stringify(u));
    await db().set('c:' + code, id);
    if (!index.includes(id)) { index.push(id); await db().set('users:index', JSON.stringify(index)); }
    return { user: u, isNew: true };
  }
  // обновляем имя/юзернейм, если изменились
  const fresh = {
    first_name: tgUser.first_name || u.first_name,
    last_name: tgUser.last_name || '',
    username: tgUser.username || '',
    photo_url: tgUser.photo_url || u.photo_url,
  };
  if (fresh.first_name !== u.first_name || fresh.username !== u.username || fresh.photo_url !== u.photo_url) {
    u = Object.assign(u, fresh);
    await db().set('u:' + id, JSON.stringify(u));
  }
  if (!index.includes(id)) { index.push(id); await db().set('users:index', JSON.stringify(index)); }
  return { user: u, isNew: false };
}

export async function saveUser(u) { await db().set('u:' + u.id, JSON.stringify(u)); }

/* ---------- авто-пара: если в боте ровно два человека ---------- */
export async function autoPair(u) {
  if (u.partnerId || u.noAuto) return u;
  const ids = await allUserIds();
  if (ids.length !== 2) return u;
  const otherId = ids.find((x) => x !== u.id);
  if (!otherId) return u;
  const other = await getUser(otherId);
  if (!other || other.partnerId) return u;
  u.partnerId = otherId;
  other.partnerId = u.id;
  await saveUser(u); await saveUser(other);
  return u;
}

export async function linkByCode(me, code) {
  code = String(code || '').trim().toUpperCase();
  if (!code) return { ok: false, error: 'Введите код партнёра' };
  const otherId = await db().get('c:' + code);
  if (!otherId) return { ok: false, error: 'Такого кода нет. Проверьте регистр и символы.' };
  if (otherId === me.id) return { ok: false, error: 'Это ваш собственный код 🙂' };
  const other = await getUser(otherId);
  if (!other) return { ok: false, error: 'Пользователь не найден' };
  me.partnerId = other.id;
  other.partnerId = me.id;
  delete me.noAuto; delete other.noAuto;
  await saveUser(me); await saveUser(other);
  return { ok: true, partner: other };
}

/* ---------- голоса ---------- */
export async function getVotes(id) {
  const raw = await db().get('v:' + id);
  return raw ? JSON.parse(raw) : {};
}
export async function setVotes(id, v) { await db().set('v:' + id, JSON.stringify(v)); }

/* ---------- мэтчи ---------- */
export async function getMatches() {
  const raw = await db().get('matches');
  return raw ? JSON.parse(raw) : [];
}
export async function setMatches(m) { await db().set('matches', JSON.stringify(m)); }

/* ---------- утилиты ---------- */
export const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status,
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
});

export const html = (body, status = 200) => new Response(body, {
  status,
  headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
});

export const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function ratingLine(m) {
  if (m.rating == null) return '';
  return `★ ${Number(m.rating).toFixed(1)} · ${m.src === 'tmdb' ? 'TMDB' : 'КиноПоиск'}`;
}
