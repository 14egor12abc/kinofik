// Основной API мини-приложения: профили, голоса, мэтчи, уведомления
import {
  getConfig, parseInitData, ensureUser, autoPair, getUser, allUserIds,
  getVotes, setVotes, getMatches, setMatches, linkByCode, saveUser,
  tg, json, esc, ratingLine, runSetup, siteUrl, db,
} from './_shared.mjs';
import { CATALOG } from './_catalog.mjs';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export default async function handler(req) {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (req.method !== 'POST') return json({ ok: false, error: 'Только POST' }, 405);

  let body;
  try { body = await req.json(); } catch (e) { return json({ ok: false, error: 'Некорректный запрос' }, 400); }

  const cfg = await getConfig();
  if (!cfg.token) return json({ ok: false, error: 'Бот ещё не настроен. Откройте страницу /setup' }, 500);

  const tgUser = parseInitData(body.initData, cfg.token);
  if (!tgUser) return json({ ok: false, error: 'Приложение нужно открывать через Telegram' }, 401);

  const { user: me } = await ensureUser(tgUser);
  const action = String(body.a || '');

  // самолечение: если адрес сайта сменился — перерегистрируем вебхук и кнопку
  if (action === 'hello') {
    const site = siteUrl(req);
    try {
      if (site && (await db().get('config:site')) !== site) {
        await runSetup(cfg.token, site);
        await db().set('config:site', site);
      }
    } catch (e) { console.warn('bootstrap', e && e.message); }
  }

  try {
    switch (action) {

      /* ---------------- приветствие / состояние ---------------- */
      case 'hello': {
        const updated = await autoPair(me);
        const partner = updated.partnerId ? await getUser(updated.partnerId) : null;
        const votes = await getVotes(updated.id);
        const all = await getMatches();
        const matches = all.filter((m) => (m.by || []).includes(updated.id));
        return json({
          ok: true,
          me: pub(updated),
          partner: partner ? pub(partner) : null,
          votes,
          matches,
          users: (await allUserIds()).length,
        });
      }

      /* ---------------- голос ---------------- */
      case 'vote': {
        const id = String(body.id || '');
        const it = CATALOG[id];
        if (!it) return json({ ok: false, error: 'Такого фильма нет в каталоге' }, 404);
        const v = Number(body.v) === 1 ? 1 : -1;

        const votes = await getVotes(me.id);
        votes[id] = v;
        await setVotes(me.id, votes);

        let match = null;
        if (v === 1 && me.partnerId) {
          const pv = await getVotes(me.partnerId);
          if (pv[id] === 1) {
            const all = await getMatches();
            if (!all.some((m) => m.id === id)) {
              const partner = await getUser(me.partnerId);
              match = {
                id, title: it.t, year: it.y, type: it.tp, poster: it.p,
                rating: it.r, src: it.s, genres: it.g || [],
                ts: Date.now(), by: [me.id, me.partnerId], watched: false,
              };
              all.unshift(match);
              await setMatches(all);
              // ВАЖНО: дожидаемся отправки. Если вернуть ответ раньше,
              // Netlify «заморозит» функцию и уведомления не уйдут.
              try {
                await withTimeout(notifyMatch(cfg.token, match, me, partner), 8000);
              } catch (e) {
                console.error('notify error', e);
              }
            }
          }
        }
        return json({ ok: true, match });
      }

      /* ---------------- отмена голоса ---------------- */
      case 'unvote': {
        const id = String(body.id || '');
        const votes = await getVotes(me.id);
        delete votes[id];
        await setVotes(me.id, votes);
        const all = await getMatches();
        const left = all.filter((m) => !(m.id === id && (m.by || []).includes(me.id)));
        if (left.length !== all.length) await setMatches(left);
        return json({ ok: true, votes, matches: left.filter((m) => (m.by || []).includes(me.id)) });
      }

      /* ---------------- убрать из мэтчей ---------------- */
      case 'unmatch': {
        const id = String(body.id || '');
        const all = await getMatches();
        const left = all.filter((m) => !(m.id === id && (m.by || []).includes(me.id)));
        await setMatches(left);
        return json({ ok: true, matches: left.filter((m) => (m.by || []).includes(me.id)) });
      }

      /* ---------------- отметили «посмотрели» ---------------- */
      case 'watched': {
        const id = String(body.id || '');
        const flag = body.v !== false;
        const all = await getMatches();
        let hit = null;
        for (const m of all) if (m.id === id && (m.by || []).includes(me.id)) { m.watched = flag; hit = m; }
        await setMatches(all);
        return json({ ok: true, matches: all.filter((m) => (m.by || []).includes(me.id)), match: hit });
      }

      /* ---------------- связать пару ---------------- */
      case 'pair': {
        const r = await linkByCode(me, body.code);
        if (!r.ok) return json({ ok: false, error: r.error });
        return json({ ok: true, partner: pub(r.partner) });
      }

      /* ---------------- разорвать пару ---------------- */
      case 'unpair': {
        if (me.partnerId) {
          const other = await getUser(me.partnerId);
          if (other && other.partnerId === me.id) { other.partnerId = null; await saveUser(other); }
        }
        me.partnerId = null;
        me.noAuto = true; // чтобы авто-пара не связала обратно против воли
        await saveUser(me);
        return json({ ok: true });
      }

      /* ---------------- сброс ---------------- */
      case 'reset': {
        await setVotes(me.id, {});
        const all = await getMatches();
        await setMatches(all.filter((m) => !(m.by || []).includes(me.id)));
        return json({ ok: true, votes: {}, matches: [] });
      }

      default:
        return json({ ok: false, error: 'Неизвестное действие: ' + action }, 400);
    }
  } catch (e) {
    console.error('api error', e);
    return json({ ok: false, error: 'Внутренняя ошибка: ' + (e && e.message ? e.message : 'unknown') }, 500);
  }
}

/* ---------- вспомогательное ---------- */
function withTimeout(promise, ms) {
  let t;
  return Promise.race([
    promise.finally(() => clearTimeout(t)),
    new Promise((_, rej) => { t = setTimeout(() => rej(new Error('timeout ' + ms + 'ms')), ms); }),
  ]);
}

function pub(u) {
  return {
    id: u.id, code: u.code, first_name: u.first_name, last_name: u.last_name,
    username: u.username, photo_url: u.photo_url, partnerId: u.partnerId,
  };
}

async function notifyMatch(token, m, a, b) {
  const caption = [
    '🎬💘 <b>МЭТЧ!</b>',
    '',
    'Вы оба хотите посмотреть:',
    `<b>«${esc(m.title)}»</b>${m.year ? ' (' + m.year + ')' : ''}`,
    ratingLine(m),
    '',
    'Осталось выбрать вечер 🍿',
  ].join('\n');
  const kb = {
    inline_keyboard: [[
      { text: '✅ Посмотрели', callback_data: 'watched:' + m.id },
      { text: '✖️ Убрать', callback_data: 'drop:' + m.id },
    ]],
  };
  const targets = [a, b].filter(Boolean);
  for (const u of targets) {
    let sent = false;
    if (m.poster) {
      const r = await tg('sendPhoto', {
        chat_id: u.id, photo: m.poster, caption, parse_mode: 'HTML',
        reply_markup: kb, disable_notification: false,
      }, token);
      sent = !!r.ok;
      if (!r.ok) console.warn('sendPhoto failed', r.description);
    }
    if (!sent) {
      await tg('sendMessage', { chat_id: u.id, text: caption, parse_mode: 'HTML', reply_markup: kb }, token);
    }
  }
}
