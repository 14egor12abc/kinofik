// Вебхук Telegram-бота: /start, команды, кнопки под уведомлениями о мэтчах
import {
  getConfig, siteUrl, tg, json, esc, ensureUser, getUser, linkByCode,
  getMatches, setMatches, getVotes, setVotes, ratingLine, allUserIds, saveUser,
  MENU_TEXT,
} from './_shared.mjs';
import { CATALOG } from './_catalog.mjs';

function keyboard(site) {
  return {
    keyboard: [[{ text: MENU_TEXT, web_app: { url: site + '/' } }]],
    resize_keyboard: true,
    is_persistent: true,
  };
}

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(
      'Это вебхук Telegram-бота. Настройку выполняйте на странице <a href="./setup">/setup</a>.',
      { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
    );
  }

  const cfg = await getConfig();
  if (!cfg.token) return json({ ok: false, error: 'no token' }, 500);

  let update;
  try { update = await req.json(); } catch (e) { return json({ ok: false }); }

  try {
    if (update.callback_query) await onCallback(update.callback_query, cfg.token);
    else if (update.message) await onMessage(update.message, cfg.token, siteUrl(req));
  } catch (e) {
    console.error('bot error', e);
  }
  // Telegram требует 200 OK, иначе будет слать обновление повторно
  return json({ ok: true });
}

/* ================= сообщения ================= */
async function onMessage(msg, token, site) {
  if (!msg.from) return;
  const chatId = msg.chat.id;
  const text = (msg.text || '').trim();
  const { user: me } = await ensureUser(msg.from);

  // переход по ссылке-приглашению: /start pair_XXXXX
  const pairStart = text.match(/^\/start(?:@\w+)?\s+pair_([A-Za-z0-9]{3,8})$/i);
  if (pairStart) {
    const r = await linkByCode(me, pairStart[1]);
    if (r.ok) {
      await tg('sendMessage', {
        chat_id: chatId, parse_mode: 'HTML', reply_markup: keyboard(site),
        text: `💞 <b>Готово!</b> Вы связаны с ${esc(r.partner.first_name || 'партнёром')}.\n\n`
          + `Теперь, когда вы оба лайкнете один и тот же фильм — случится <b>мэтч</b>, и мы напишем вам обоим.\n\n`
          + `Жмите «${MENU_TEXT}» 👇`,
      }, token);
      // второму тоже сообщим
      await tg('sendMessage', {
        chat_id: r.partner.id, parse_mode: 'HTML',
        text: `💞 ${esc(me.first_name || 'Партнёр')} подключился(ась) к вам в «КиноФикации». Можно свайпать!`,
      }, token);
      return;
    }
    await tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML', reply_markup: keyboard(site),
      text: `⚠️ Не удалось связать пару: ${esc(r.error)}`,
    }, token);
    return;
  }

  if (/^\/start/.test(text)) {
    // если в боте ровно двое — связываем автоматически
    const ids = await allUserIds();
    if (ids.length === 2 && !me.partnerId) {
      const otherId = ids.find((x) => x !== me.id);
      const other = otherId ? await getUser(otherId) : null;
      if (other && !other.partnerId) {
        me.partnerId = other.id; other.partnerId = me.id;
        delete me.noAuto; delete other.noAuto;
        await saveUser(me); await saveUser(other);
        await tg('sendMessage', {
          chat_id: other.id, parse_mode: 'HTML',
          text: `💞 ${esc(me.first_name || 'Новый участник')} подключился(ась) — вы теперь пара!`,
        }, token);
      }
    }
    const fresh = await getUser(me.id);
    const partner = fresh && fresh.partnerId ? await getUser(fresh.partnerId) : null;
    await tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML', reply_markup: keyboard(site),
      text:
        `🎬 <b>КиноФикация</b> — привет${me.first_name ? ', ' + esc(me.first_name) : ''}!\n\n`
        + `Это «Тиндер для кино»: листаете карточки фильмов и сериалов, ставите ❤️ или ✖️. `
        + `Как только вы с партнёром оба лайкнете одно и то же — случится <b>мэтч</b>, и фильм попадёт в общий список.\n\n`
        + (partner
          ? `💞 Вы связаны с: <b>${esc(partner.first_name || 'партнёром')}</b>\n`
          : `👥 Партнёр пока не подключён.\nВаш код: <code>${esc(me.code)}</code>\n`
            + `Откройте приложение → вкладка «Пара» → «Отправить ссылку партнёру».\n`)
        + `\nЖмите <b>«${MENU_TEXT}»</b> ниже 👇\n\n`
        + `<i>Команды: /matches — список мэтчей, /pair — связать пару, /reset — начать заново, /help — справка.</i>`,
    }, token);
    return;
  }

  if (/^\/matches/.test(text)) return sendMatches(chatId, me, token, site);
  if (/^\/help/.test(text)) return sendHelp(chatId, token);

  const pairCmd = text.match(/^\/pair(?:@\w+)?\s+([A-Za-z0-9]{3,8})$/i);
  if (pairCmd) {
    const r = await linkByCode(me, pairCmd[1]);
    return tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML',
      text: r.ok ? `💞 Готово! Вы связаны с ${esc(r.partner.first_name || 'партнёром')}.` : `⚠️ ${esc(r.error)}`,
    }, token);
  }
  if (/^\/pair/.test(text)) {
    return tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML',
      text: `👥 Ваш код: <code>${esc(me.code)}</code>\n\nОтправьте его партнёру — он введёт код во вкладке «Пара» в приложении `
        + `или напишет боту: <code>/pair ${esc(me.code)}</code>`,
    }, token);
  }

  if (/^\/reset/.test(text)) {
    await setVotes(me.id, {});
    const all = await getMatches();
    await setMatches(all.filter((m) => !(m.by || []).includes(me.id)));
    return tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML',
      text: '🧹 Готово: ваши оценки и мэтчи удалены. Карточки начнутся заново.',
    }, token);
  }

  if (/^\/code/.test(text)) {
    return tg('sendMessage', { chat_id: chatId, parse_mode: 'HTML', text: `👥 Ваш код для связи: <code>${esc(me.code)}</code>` }, token);
  }

  // обычный текст
  await tg('sendMessage', {
    chat_id: chatId, parse_mode: 'HTML', reply_markup: keyboard(site),
    text: `Я не умею читать обычные сообщения 🙂\n\nВесь выбор кино — в мини-приложении. Жмите <b>«${MENU_TEXT}»</b> ниже 👇\n\n`
      + `<i>Или введите /help, чтобы увидеть команды.</i>`,
  }, token);
}

async function sendMatches(chatId, me, token, site) {
  const all = await getMatches();
  const mine = all.filter((m) => (m.by || []).includes(me.id));
  if (!mine.length) {
    return tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML', reply_markup: keyboard(site),
      text: '💔 Мэтчей пока нет.\n\nСвайпайте карточки в приложении — как только вы оба лайкнете один фильм, он появится здесь.',
    }, token);
  }
  const active = mine.filter((m) => !m.watched);
  const lines = mine.slice(0, 40).map((m, i) => {
    const it = CATALOG[m.id] || {};
    return `${i + 1}. ${m.watched ? '✅' : '🎬'} <b>${esc(m.title)}</b>${m.year ? ' (' + m.year + ')' : ''}`
      + (it.tp === 'series' ? ' · сериал' : '') + (m.rating ? ` · ★ ${Number(m.rating).toFixed(1)}` : '');
  }).join('\n');
  await tg('sendMessage', {
    chat_id: chatId, parse_mode: 'HTML',
    text: `🍿 <b>Ваши мэтчи (${active.length} к просмотру, всего ${mine.length})</b>\n\n${lines}`,
  }, token);
}

function sendHelp(chatId, token) {
  return tg('sendMessage', {
    chat_id: chatId, parse_mode: 'HTML',
    text: `🎬 <b>КиноФикация — как это работает</b>\n\n`
      + `1️⃣ Откройте приложение кнопкой внизу.\n`
      + `2️⃣ Свайп <b>вправо</b> — «хочу посмотреть», <b>влево</b> — «мимо».\n`
      + `3️⃣ Когда вы с партнёром оба лайкнете один фильм — <b>мэтч</b>! Я пришлю уведомление обоим.\n`
      + `4️⃣ Все мэтчи копятся во вкладке «Мэтчи» — это ваш общий список на вечер.\n\n`
      + `<b>Команды</b>\n`
      + `/matches — список мэтчей\n`
      + `/code — мой код для связи с партнёром\n`
      + `/pair КОД — связаться с партнёром\n`
      + `/reset — стереть мои оценки и мэтчи\n`
      + `/help — эта справка`,
  }, token);
}

/* ================= inline-кнопки ================= */
async function onCallback(cb, token) {
  const data = String(cb.data || '');
  const chatId = cb.message && cb.message.chat ? cb.message.chat.id : cb.from.id;
  const [cmd, id] = data.split(':');
  const { user: me } = await ensureUser(cb.from);
  const all = await getMatches();
  const m = all.find((x) => x.id === id && (x.by || []).includes(me.id));

  if (cmd === 'watched') {
    if (m) { m.watched = !m.watched; await setMatches(all); }
    await tg('answerCallbackQuery', { callback_query_id: cb.id, text: m && m.watched ? 'Отмечено как просмотренное ✅' : 'Снята отметка' }, token);
    if (cb.message) await tg('editMessageText', {
      chat_id: chatId, message_id: cb.message.message_id, parse_mode: 'HTML',
      text: m && m.watched ? `✅ <b>«${esc(m.title)}»</b> — посмотрели! Приятного вечера 🍿` : `↩️ «${esc(m ? m.title : '')}» снова в списке к просмотру`,
    }, token);
    return;
  }

  if (cmd === 'drop') {
    const left = all.filter((x) => !(x.id === id && (x.by || []).includes(me.id)));
    await setMatches(left);
    // убираем лайк, чтобы фильм мог вернуться в колоду
    const v = await getVotes(me.id); delete v[id]; await setVotes(me.id, v);
    await tg('answerCallbackQuery', { callback_query_id: cb.id, text: 'Убрано из мэтчей' }, token);
    if (cb.message) await tg('deleteMessage', { chat_id: chatId, message_id: cb.message.message_id }, token);
    return;
  }

  await tg('answerCallbackQuery', { callback_query_id: cb.id }, token);
}
